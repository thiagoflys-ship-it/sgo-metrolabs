const SGO_UTILS = {

  /* =========================
     GERADORES
  ========================== */
  uuid() {
    return Utilities.getUuid();
  },

  now() {
    return new Date();
  },

  nowIso() {
    return new Date().toISOString();
  },

  /* =========================
     TRATAMENTO DE DADOS
  ========================== */
  safe(v) {
    return (v === null || v === undefined) ? "" : String(v).trim();
  },

  safeUpper(v) {
    return SGO_UTILS.safe(v).toUpperCase();
  },

  safeLower(v) {
    return SGO_UTILS.safe(v).toLowerCase();
  },

  onlyDigits(v) {
    return SGO_UTILS.safe(v).replace(/\D/g, "");
  },

  /* =========================
     CONVERSÕES
  ========================== */
  toNumber(v, def = 0) {
    try {
      if (v === null || v === undefined || v === "") return def;
      // Trata formato de moeda brasileiro (ex: 1.000,50 -> 1000.50)
      const n = Number(String(v).replace(/\./g, "").replace(",", "."));
      return isNaN(n) ? def : n;
    } catch (e) {
      return def;
    }
  },

  toBoolean(v) {
    if (typeof v === "boolean") return v;
    const val = SGO_UTILS.safeLower(v);
    return val === "true" || val === "1" || val === "sim" || val === "on" || val === "s";
  },

  /* =========================
     VALIDAÇÕES
  ========================== */
  isEmpty(v) {
    return SGO_UTILS.safe(v) === "";
  },

  isNotEmpty(v) {
    return !SGO_UTILS.isEmpty(v);
  },

  isEmail(v) {
    const email = SGO_UTILS.safe(v);
    if (!email) return false;
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  },

  isCnpj(v) {
    const cnpj = SGO_UTILS.onlyDigits(v);
    if (cnpj.length !== 14) return false;
    
    // Elimina CNPJs inválidos conhecidos (ex: 00000000000000)
    if (/^(\d)\1+$/.test(cnpj)) return false;

    // Validação matemática real dos dígitos verificadores do CNPJ
    let tamanho = cnpj.length - 2;
    let numeros = cnpj.substring(0, tamanho);
    let digitos = cnpj.substring(tamanho);
    let soma = 0;
    let pos = tamanho - 7;
    for (let i = tamanho; i >= 1; i--) {
      soma += numeros.charAt(tamanho - i) * pos--;
      if (pos < 2) pos = 9;
    }
    let resultado = soma % 11 < 2 ? 0 : 11 - soma % 11;
    if (resultado != digitos.charAt(0)) return false;

    tamanho = tamanho + 1;
    numeros = cnpj.substring(0, tamanho);
    soma = 0;
    pos = tamanho - 7;
    for (let i = tamanho; i >= 1; i--) {
      soma += numeros.charAt(tamanho - i) * pos--;
      if (pos < 2) pos = 9;
    }
    resultado = soma % 11 < 2 ? 0 : 11 - soma % 11;
    if (resultado != digitos.charAt(1)) return false;

    return true;
  },

  // 29/10/2026 (cadastro completo de cliente): CPF para cliente pessoa física, com os dois dígitos verificadores.
  isCpf(v) {
    const cpf = SGO_UTILS.onlyDigits(v);
    if (cpf.length !== 11 || /^(\d)\1+$/.test(cpf)) return false;
    const dv = function (n) {
      let soma = 0;
      for (let i = 0; i < n; i++) soma += Number(cpf.charAt(i)) * (n + 1 - i);
      const r = (soma * 10) % 11;
      return r === 10 ? 0 : r;
    };
    return dv(9) === Number(cpf.charAt(9)) && dv(10) === Number(cpf.charAt(10));
  },

  formatCpf(v) {
    const cpf = SGO_UTILS.onlyDigits(v);
    return cpf.length === 11 ? cpf.replace(/^(\d{3})(\d{3})(\d{3})(\d{2})$/, "$1.$2.$3-$4") : SGO_UTILS.safe(v);
  },

  /* =========================
     NORMALIZAÇÃO E FORMATAÇÃO
  ========================== */
  normalizeCnpj(v) {
    return SGO_UTILS.onlyDigits(v);
  },

  // Recupera apenas identificadores legados cujo preenchimento com zero passa no DV.
  // A entrada de novos cadastros continua estrita (normalizeCnpj/isCnpj).
  cnpjArmazenado(v) {
    const digitos = SGO_UTILS.onlyDigits(v);
    if (digitos.length > 0 && digitos.length < 14) {
      const candidato = digitos.padStart(14, '0');
      if (SGO_UTILS.isCnpj(candidato)) return candidato;
    }
    return digitos;
  },

  formatCnpj(v) {
    const cnpj = SGO_UTILS.cnpjArmazenado(v);
    if (cnpj.length !== 14) return SGO_UTILS.safe(v);

    return cnpj.replace(
      /^(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})$/,
      "$1.$2.$3/$4-$5"
    );
  },

  normalizePhone(v) {
    return SGO_UTILS.onlyDigits(v);
  },

  formatPhone(v) {
    let phone = SGO_UTILS.onlyDigits(v);
    if (phone.length === 11) {
      return phone.replace(/^(\d{2})(\d{5})(\d{4})$/, "($1) $2-$3");
    } else if (phone.length === 10) {
      return phone.replace(/^(\d{2})(\d{4})(\d{4})$/, "($1) $2-$3");
    }
    return SGO_UTILS.safe(v);
  },

  /* =========================
     TEXTO
  ========================== */
  truncate(texto, limite = 100) {
    const t = SGO_UTILS.safe(texto);
    if (t.length <= limite) return t;
    return t.substring(0, limite) + "...";
  },

  /* =========================
     DATA / FORMATAÇÃO
  ========================== */
  formatDateBR(date) {
    try {
      if (!date) return "";
      const d = new Date(date);
      // Busca o timezone configurado em SGO_CFG (se existir), senão usa o padrão do script
      const tz = (typeof SGO_CFG !== "undefined" && SGO_CFG.SISTEMA && SGO_CFG.SISTEMA.TIMEZONE) 
                 ? SGO_CFG.SISTEMA.TIMEZONE 
                 : Session.getScriptTimeZone();
      return Utilities.formatDate(d, tz, "dd/MM/yyyy HH:mm");
    } catch (e) {
      return "";
    }
  },

  /* =========================
     OBJETO / CLONE
  ========================== */
  clone(obj) {
    try {
      return JSON.parse(JSON.stringify(obj));
    } catch (e) {
      return {};
    }
  },

  merge(base, extra) {
    return Object.assign({}, base || {}, extra || {});
  },

  /* =========================
     LOG AUXILIAR
  ========================== */
  log(label, data) {
    try {
      const msg = (typeof data === 'object') ? JSON.stringify(data) : data;
      Logger.log(`${label} => ${msg}`);
    } catch (e) {
      Logger.log(label);
    }
  }

};
/**
 * 16/11/2026 (decisão do dono, confirmada): "no começo somente eu e o Charles aprovam" — vale para TODAS as aprovações
 * financeiras (alçada do Omie, Compras, Depósito de viagem, Recarga Caju). Configuração em Administração > Chaves e senhas >
 * Regras do Financeiro: APROVACAO_SO_DIRETORIA. Sem valor ou SIM = só o dono do sistema e a Diretoria aprovam (padrão);
 * NAO = voltam as regras de antes de cada módulo (faixas de Compras, gerência na viagem). As faixas não são apagadas.
 */
function SGO_aprovacaoSoDiretoria_() {
  var v = '';
  try { v = String(PropertiesService.getScriptProperties().getProperty('APROVACAO_SO_DIRETORIA') || '').trim().toUpperCase(); } catch (e) { v = ''; }
  return v !== 'NAO' && v !== 'NÃO';
}
/** A pessoa é o dono do sistema ou da Diretoria (perfil ou área)? u: { login|usuario, perfil, area }. */
function SGO_ehDonoOuDiretoria_(u) {
  if (!u) return false;
  var login = String(u.login || u.usuario || '').trim();
  if (login && typeof Chaves_ehDonoUsuario_ === 'function' && Chaves_ehDonoUsuario_(login)) return true;
  return String(u.perfil || '').trim().toUpperCase() === 'DIRETORIA' || String(u.area || '').trim().toUpperCase() === 'DIRETORIA';
}
var SGO_MSG_SO_DIRETORIA_APROVA = 'por decisão do dono, no começo só o dono do sistema e a Diretoria aprovam as despesas e compras da empresa (Administração > Chaves e senhas > Regras do Financeiro > Aprovação só do dono e da Diretoria)';
