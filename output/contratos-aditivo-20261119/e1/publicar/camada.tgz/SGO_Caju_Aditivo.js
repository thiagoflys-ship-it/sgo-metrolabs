/****************************************************
 * ADITIVO DE RECARGA EM VIAGEM (19/11/2026, etapa E1b do estudo output/contratos-aditivo-20261119/ESTUDO.md, seção 2)
 *
 * Para que serve: no meio da viagem aparece um gasto que não estava no orçamento (peça, usinagem, hotel a mais...). O técnico pede,
 * pelo celular (app de campo ou SGO+ na web), um ADITIVO de recarga no cartão Caju, sem mexer na solicitação aprovada: a viagem
 * continua aprovada e carregada (a marca SHA-256 da revisão aprovada não muda). Decisões do dono (recomendações da seção 6):
 *  - basta UM sócio (o dono ou quem é da Diretoria; ninguém decide o aditivo da viagem em que pediu ou viaja); sem teto automático;
 *  - o gestor da área de quem pediu só ACOMPANHA e pode registrar um parecer, que aparece para os sócios (não trava);
 *  - nada é aprovado por tempo: aviso na hora aos sócios (a qualquer hora quando "estou parado aguardando"), lembrete aos 30 min e,
 *    aos 60 min, tarefa à Wanessa (Financeiro) e ao gestor da área para ligar para os sócios (tempos na política de viagem);
 *  - aprovado, o valor SOMA ao teto de carga da viagem (Via_tetoCarga_): a carga segue pelo caminho que já existe (Financeiro, manual
 *    com comprovante ou pela API do Caju quando ligada). À noite, sem o Financeiro: o outro sócio registra a carga; se nenhum puder,
 *    o próprio aprovador registra como EXCEÇÃO (MESMA_PESSOA, com o motivo) e a Wanessa confere no dia útil seguinte (pendência);
 *  - a peça comprada com aditivo NÃO vira compra em Compras (só a visão de leitura "Peças compradas em viagem");
 *  - "Repassar ao cliente?" (a definir por padrão); "Sim" vira tarefa ao Comercial (sem valor para quem não vê o valor da viagem);
 *  - a prestação de contas é a da própria viagem (prazo de 3 dias úteis): cada gasto pode ser marcado com o aditivo, e o A4 de
 *    fechamento mostra o previsto (orçado + aditivos) contra o realizado.
 * Recarga Caju da ROTINA: o pedido avulso que já existe (Minha recarga Caju > Pedir recarga) cumpre o papel do aditivo; a tela do aditivo
 * aponta o caminho quando a pessoa não tem viagem em andamento. A tabela CJU_ADITIVOS já guarda ORIGEM_TIPO para a rotina no futuro.
 * SIGILO: o valor só aparece para quem já vê o valor da viagem (Via_podeVer_) e para os sócios; o gestor que não vê a viagem recebe
 * o aviso sem valor; o Comercial recebe a tarefa de repasse sem valor.
 * Avisos: GS12 (fila dos avisos da gestão, modelo sgo_gestao_acao) aos sócios, ao gestor e ao Financeiro; VG01 (matriz) a quem pediu.
 * Ordem de carga: carrega antes de SGO_Viagem*.js; no nível do arquivo só há constantes literais. Nenhuma função devolve Date cru.
 ****************************************************/

var ADT_ABA = 'CJU_ADITIVOS';
var ADT_COLUNAS = ['ID', 'NUMERO', 'ORIGEM_TIPO', 'ORIGEM_ID', 'ORIGEM_NUMERO', 'SEQ', 'SOLICITANTE_ID', 'SOLICITANTE_NOME', 'PORTADOR_ID', 'PORTADOR_NOME', 'CATEGORIA',
  'VALOR_PEDIDO', 'JUSTIFICATIVA', 'URGENCIA', 'VINCULO_TIPO', 'VINCULO_REF', 'CLIENTE_ID', 'CLIENTE_NOME', 'REPASSAR_CLIENTE', 'ANEXOS_JSON', 'COMPLEMENTOS_JSON', 'SITUACAO',
  'PARECER_GESTOR', 'PARECER_TEXTO', 'PARECER_POR_ID', 'PARECER_POR_NOME', 'PARECER_EM', 'INFO_PEDIDA', 'INFO_PEDIDA_POR_NOME', 'INFO_PEDIDA_EM', 'VALOR_APROVADO',
  'DECIDIDO_POR_ID', 'DECIDIDO_POR_NOME', 'DECIDIDO_EM', 'FUNDAMENTACAO', 'CARREGADO_TOTAL', 'CARREGADO_EM', 'CARGA_ID', 'MESMA_PESSOA', 'EXCECAO_MOTIVO', 'EXCECAO_POR_NOME',
  'EXCECAO_CONFERIDA_EM', 'EXCECAO_CONFERIDA_POR_NOME', 'EXCECAO_CONFERIDA_TEXTO', 'LIBERACAO_ID', 'REPASSE_TRATADO_EM', 'REPASSE_TRATADO_POR_NOME', 'REPASSE_TEXTO',
  'ENVIADO_EM', 'LEMBRETE_EM', 'ESCALADO_EM', 'MARCA', 'CRIADO_EM', 'ATUALIZADO_EM', 'CANCELADO_EM', 'CANCELADO_MOTIVO', 'CANCELADO_POR_NOME',
  // quando os sócios foram avisados (pedido que pode esperar, feito fora do expediente: avisa na abertura do expediente)
  'AVISO_SOCIOS_EM'];
var ADT_COLUNAS_TEXTO = ['NUMERO', 'ORIGEM_NUMERO', 'PARECER_EM', 'INFO_PEDIDA_EM', 'DECIDIDO_EM', 'CARREGADO_EM', 'EXCECAO_CONFERIDA_EM', 'REPASSE_TRATADO_EM', 'ENVIADO_EM', 'LEMBRETE_EM',
  'ESCALADO_EM', 'CRIADO_EM', 'ATUALIZADO_EM', 'CANCELADO_EM', 'AVISO_SOCIOS_EM'];
var ADT_CATEGORIAS = [['PECA', 'Peça'], ['USINAGEM', 'Usinagem ou serviço de terceiro'], ['HOSPEDAGEM_EXTRA', 'Hospedagem extra'], ['ALIMENTACAO_EXTRA', 'Alimentação extra'],
  ['COMBUSTIVEL_EXTRA', 'Combustível extra'], ['PEDAGIO_ESTACIONAMENTO', 'Pedágio e estacionamento'], ['TRANSPORTE_LOCAL', 'Transporte local'], ['FERRAMENTA_MATERIAL', 'Ferramenta ou material'], ['OUTRO', 'Outro']];
/** Categorias que aparecem em Compras > Relatórios > "Peças compradas em viagem" (só leitura). */
var ADT_CATS_PECA = ['PECA', 'USINAGEM', 'FERRAMENTA_MATERIAL'];
var ADT_SITUACOES = { AGUARDANDO: 'Aguardando os sócios', INFORMACAO: 'Pedido de informação', APROVADO: 'Aprovado, aguardando a carga', CARREGADO: 'Carregado no cartão',
  NEGADO: 'Negado', CANCELADO: 'Cancelado' };
var ADT_ABERTOS = ['AGUARDANDO', 'INFORMACAO'];
var ADT_URGENCIAS = { PARADO: 'Estou parado aguardando (aviso a qualquer hora)', HOJE: 'Pode ser decidido hoje' };
var ADT_REPASSAR = { A_DEFINIR: 'A definir', SIM: 'Sim, repassar ao cliente', NAO: 'Não repassar' };
var ADT_PARECERES = { CONFIRMO: 'Confirmo que é necessário', NAO_VEJO: 'Não vejo necessidade' };
var ADT_JUSTIFICATIVA_MIN = 20;
var ADT_MOTIVO_MIN = 15;
var ADT_EXEMPLO = 'Usinagem do eixo da bomba da autoclave, peça quebrada na desmontagem; sem ela o equipamento não volta a operar.';
var ADT_EVENTO_GESTAO = 'GS12';
var ADT_EVENTO_PEDINTE = 'VG01';
/** Origem do aviso a quem pediu quando ele está parado aguardando: a resposta sai na hora, a qualquer horário (SGO_Avisos_Matriz.js). */
var ADT_ORIGEM_PARADO = 'ADITIVO_PARADO';
var ADT_MEMO = null;

function Adt_memoLimpar_() { ADT_MEMO = null; }
function Adt_garantirAba_() {
  var cache = null;
  try { cache = CacheService.getScriptCache(); if (cache.get('ADT_ABA_OK_V1')) return; } catch (e) { cache = null; }
  CertCal_garantirTabela_(ADT_ABA, ADT_COLUNAS);
  ADT_COLUNAS.forEach(function (c) { CertCal_garantirColuna_(ADT_ABA, c); });
  if (typeof CertCal_forcarColunaTexto_ === 'function') ADT_COLUNAS_TEXTO.forEach(function (c) { CertCal_forcarColunaTexto_(ADT_ABA, c); });
  try { if (typeof SGO_DATA !== 'undefined') { SGO_DATA._headersCache = {}; SGO_DATA._headerMapCache = {}; } } catch (e) {}
  try { if (cache) cache.put('ADT_ABA_OK_V1', '1', 21600); } catch (e) {}
}
/** Todos os aditivos (memória de 3 segundos, limpa a cada gravação e a cada chamada da tela). */
function Adt_todos_() {
  if (ADT_MEMO && Date.now() - ADT_MEMO.em < 3000) return ADT_MEMO.l;
  var l = [];
  try { l = Via_ler_(ADT_ABA); } catch (e) { l = []; }
  ADT_MEMO = { em: Date.now(), l: l };
  return l;
}
function Adt_doId_(id) {
  var a = Via_s_(id) ? SGO_DATA.getById(ADT_ABA, Via_s_(id)) : null;
  if (!a) throw new Error('Aditivo não encontrado. Atualize a tela e abra de novo.');
  return a;
}
function Adt_daViagem_(solId) {
  return Adt_todos_().filter(function (a) { return Via_up_(a.ORIGEM_TIPO || 'VIAGEM') === 'VIAGEM' && Via_s_(a.ORIGEM_ID) === Via_s_(solId); })
    .sort(function (a, b) { return (Number(a.SEQ) || 0) - (Number(b.SEQ) || 0); });
}
function Adt_aprovadoValor_(a) { return ['APROVADO', 'CARREGADO'].indexOf(Via_up_(a.SITUACAO)) >= 0 ? Via_r2_(Number(a.VALOR_APROVADO) || 0) : 0; }
/** Soma dos aditivos aprovados da viagem (entra no teto de carga: Via_tetoCarga_ em SGO_Viagem.js). */
function Adt_aprovadosDe_(solId) {
  if (!Via_s_(solId)) return 0;
  return Via_r2_(Adt_daViagem_(solId).reduce(function (s, a) { return s + Adt_aprovadoValor_(a); }, 0));
}
function Adt_nomeCat_(c) { var x = ADT_CATEGORIAS.filter(function (k) { return k[0] === Via_up_(c); })[0]; return x ? x[1] : Via_s_(c); }
function Adt_noExpediente_() { try { return typeof SGO_dentroDoExpediente_ === 'function' ? !!SGO_dentroDoExpediente_(new Date()).dentro : true; } catch (e) { return true; } }
/** Desde quando o aditivo espera os sócios (o lembrete e a tarefa contam daqui). */
function Adt_desde_(a) { return Via_s_(a.AVISO_SOCIOS_EM) || Via_s_(a.ENVIADO_EM); }
function Adt_min_(iso) { var s = Via_iso_(iso); if (!s) return null; var t = Date.parse(s.slice(0, 19) + '-03:00'); return isFinite(t) ? t / 60000 : null; }
function Adt_hora_(iso) { return Via_br_(iso).slice(11, 16); }
function Adt_somarMin_(iso, n) { var m = Adt_min_(iso); return m === null ? '' : Utilities.formatDate(new Date((m + n) * 60000), VIA_FUSO, "yyyy-MM-dd'T'HH:mm:ss"); }
function Adt_historico_(a, acao, eu, texto) {
  Via_historico_('ADITIVO', Via_s_(a.ID), acao, eu, { texto: texto });
  Via_historico_('SOLICITACAO', Via_s_(a.ORIGEM_ID), 'ADITIVO_' + acao, eu, { texto: Via_s_(a.NUMERO) + ': ' + texto });
}
function Adt_atualizar_(id, campos) { Adt_memoLimpar_(); campos.ATUALIZADO_EM = Via_agora_(); SGO_DATA.update(ADT_ABA, id, campos); return SGO_DATA.getById(ADT_ABA, id); }

// ------------------------------------------------------------
// POLÍTICA (na política de viagem, VIA_POLITICA)
// ------------------------------------------------------------
function Adt_politica_() {
  var p = Via_politica_();
  return { lembreteMin: Number(p.aditivoLembreteMin) || 30, escalarMin: Number(p.aditivoEscalarMin) || 60, fotoAcimaDe: p.aditivoFotoAcimaDe || null };
}

// ------------------------------------------------------------
// QUEM FAZ O QUÊ
// ------------------------------------------------------------
function Adt_ehSocio_(u) { return !!u && Via_ehDonoOuDiretoria_({ login: u.login || u.usuario, perfil: u.perfil, area: u.area }); }
/** Quem não decide este aditivo: quem pediu a viagem, a equipe, quem pediu o aditivo e o portador. */
function Adt_conflito_(a, r) { return Via_conflito_(r).concat([Via_s_(a.SOLICITANTE_ID), Via_s_(a.PORTADOR_ID)]).filter(function (x, i, l) { return x && l.indexOf(x) === i; }); }
/** Sócios que podem decidir (dono e Diretoria ativos), menos os impedidos. */
function Adt_socios_(a, r) { return Via_aprovadoresSoDir_(Adt_conflito_(a, r)); }
/** Gestor(es) da área de quem pediu o aditivo (Regras e responsáveis da Caixa de decisões), fora os sócios e os impedidos. */
function Adt_gestores_(a, r) {
  // o gestor acompanha e opina (não decide): só quem pediu o aditivo fica de fora (o gestor que pediu a viagem também opina)
  var us = Via_usuarios_(), u = us[Via_s_(a.SOLICITANTE_ID)], area = u ? u.area : '', imp = [Via_s_(a.SOLICITANTE_ID)], l = [];
  try { l = (((typeof Ges_cfg_ === 'function' ? Ges_cfg_() : {}).gestoresPorArea || {})[area] || []).map(Via_s_); } catch (e) { l = []; }
  return l.filter(function (id, i) { return us[id] && us[id].ativo && imp.indexOf(id) < 0 && !Via_ehDonoOuDiretoria_(us[id]) && l.indexOf(id) === i; });
}
/** Financeiro que carrega (caixa VIAGEM_DEPOSITAR, quem já vê os valores da viagem), menos quem viaja. */
function Adt_financeiro_(r) { return Via_depositantes_().filter(function (id) { return Via_equipeIds_(r).indexOf(id) < 0; }); }
/**
 * Gancho de Via_acoes_ (SGO_Viagem.js): quem aprovou o aditivo não faz a carga dele pelo caminho comum (separação de funções). Vale quando
 * o que falta carregar é só de aditivos aprovados por esta pessoa; fora do expediente, ela usa a carga de exceção no próprio aditivo.
 */
function Adt_ajustarCargaViagem_(eu, r, a) {
  if (!a || !a.carga || !a.carga.pode) return a;
  var base = typeof Via_recargaAprovada_ === 'function' ? Via_recargaAprovada_(r) : Number(r.APROVADO_TOTAL) || 0;
  if (Via_cent_(r.CARREGADO_TOTAL) < Via_cent_(base)) return a;
  var al = Adt_alocacao_(r), pend = Adt_daViagem_(r.ID).filter(function (x) { return (al[Via_s_(x.ID)] || {}).falta > 0; });
  if (pend.length && pend.every(function (x) { return Via_s_(x.DECIDIDO_POR_ID) === eu.id; })) a.carga = { pode: false, motivo: 'Falta carregar só o aditivo ' + pend.map(function (x) { return Via_s_(x.NUMERO); }).join(', ') + ', que você aprovou: a carga é do Financeiro ou do outro sócio (separação de funções). Fora do expediente, sem ninguém para carregar, registre como exceção no próprio aditivo.' };
  return a;
}
/** A pessoa vê o valor? Quem já vê o valor da viagem (Via_podeVer_), os sócios e quem pediu o aditivo. */
function Adt_veValor_(eu, a, r) {
  if (Via_s_(a.SOLICITANTE_ID) === eu.id || Via_s_(a.PORTADOR_ID) === eu.id || Adt_ehSocio_(eu)) return true;
  try { return Via_podeVer_(eu, r); } catch (e) { return false; }
}
/** Para Compras (relatório "Peças compradas em viagem"): a pessoa vê os valores do Depósito de viagem? */
function Adt_veValorViagem_(u) {
  try { var eu = { id: Via_s_(u.id), login: Via_s_(u.login).toLowerCase(), perfil: Via_up_(u.perfil), nome: Via_s_(u.nome) }; var p = Via_poderes_(eu); return !!(p.VIAGEM_VER_TODAS || p.VIAGEM_DEPOSITAR || p.VIAGEM_CONFERIR) || Adt_ehSocio_(eu); } catch (e) { return false; }
}
/** Viagem em que esta pessoa pode pedir aditivo agora: null = pode; senão o motivo (o quê, por quê e o que fazer). */
function Adt_motivoViagem_(eu, r) {
  var s = Via_up_(r.SITUACAO), num = Via_s_(r.NUMERO), hoje = Via_hoje_();
  if (Via_s_(r.SOLICITANTE_ID) !== eu.id && Via_equipeIds_(r).indexOf(eu.id) < 0) return 'Você não está na equipe da viagem ' + num + ' nem a pediu: quem pede o aditivo é quem viaja ou quem pediu a viagem.';
  if (VIA_POS_CARGA.indexOf(s) >= 0) return 'A prestação de contas da viagem ' + num + ' já foi enviada: a conta fechou. Gasto depois disso entra como reembolso, conferido pelo Financeiro.';
  if (['APROVADA', 'CARGA_FEITA'].indexOf(s) < 0 || Via_up_(r.APROVACAO_VALIDA) !== 'SIM') return 'A viagem ' + num + ' ainda não está aprovada (' + (VIA_SITUACOES[s] || s).toLowerCase() + '). Antes da aprovação, quem pediu a viagem ajusta a própria solicitação.';
  var ini = Via_somarDias_(Via_dia_(r.SAIDA_EM), -1), fim = Via_somarDias_(Via_dia_(r.CHEGADA_EM), 1);
  if (!Via_dia_(r.SAIDA_EM) || hoje < ini) return 'A viagem ' + num + ' começa em ' + Via_brDia_(r.SAIDA_EM) + ': o aditivo é para gasto que aparece durante a viagem (a partir da véspera). Antes disso, peça a quem pediu a viagem para ajustar a solicitação.';
  if (hoje > fim) return 'A viagem ' + num + ' terminou em ' + Via_brDia_(r.CHEGADA_EM) + ': o aditivo vale até o dia seguinte à volta. Gasto feito com dinheiro próprio entra na prestação de contas e vira reembolso.';
  return null;
}

// ------------------------------------------------------------
// PEDIR, CANCELAR, COMPLEMENTAR, PARECER
// ------------------------------------------------------------
function Adt_salvarAnexo_(arq, r, numero, oQue) {
  var sv = Via_salvarArquivo_(arq, Via_s_(r.NUMERO), 'Aditivo ' + numero.replace(/^.*\//, ''), oQue);
  return { nome: sv.nome, url: sv.url, sha: sv.sha, em: Via_agora_() };
}
/** d: { viagemId, categoria, valor, justificativa, urgencia (PARADO | HOJE), repassar, vinculoRef, foto }. */
function Adt_pedir_(eu, d) {
  d = d || {};
  var cat = Via_up_(d.categoria), valor = Via_num_(d.valor), just = Via_texto_(d.justificativa, 1500), urg = ADT_URGENCIAS[Via_up_(d.urgencia)] ? Via_up_(d.urgencia) : '';
  var rep = ADT_REPASSAR[Via_up_(d.repassar)] ? Via_up_(d.repassar) : 'A_DEFINIR', pol = Adt_politica_(), foto = d.foto && Via_s_(d.foto.base64) ? d.foto : null;
  if (!Via_s_(d.viagemId)) throw new Error('Não foi possível pedir o aditivo: escolha a viagem. Se a lista está vazia, você não tem viagem em andamento; para gasto da rotina, use Minha recarga Caju > Pedir recarga.');
  if (!ADT_CATEGORIAS.some(function (k) { return k[0] === cat; })) throw new Error('Não foi possível pedir o aditivo: escolha a categoria (peça, usinagem, hospedagem extra...).');
  if (valor === null || !(valor > 0)) throw new Error('Não foi possível pedir o aditivo: informe o valor em reais, maior que zero (por exemplo 350,00).');
  if (valor > (typeof VIA_VALOR_MAX_GASTO !== 'undefined' ? VIA_VALOR_MAX_GASTO : 100000)) throw new Error('Não foi possível pedir o aditivo: ' + Via_moeda_(valor) + ' passa do maior valor aceito para um pedido. Confira o valor digitado.');
  if (Via_letras_(just) < ADT_JUSTIFICATIVA_MIN) throw new Error('Não foi possível pedir o aditivo: escreva para que é o dinheiro (' + ADT_JUSTIFICATIVA_MIN + ' letras ou mais), por exemplo: "' + ADT_EXEMPLO + '" Os sócios decidem por este texto.');
  if (!urg) throw new Error('Não foi possível pedir o aditivo: diga se você está parado aguardando (os sócios recebem o aviso a qualquer hora) ou se pode ser decidido hoje.');
  if (!foto && (cat === 'OUTRO' || (pol.fotoAcimaDe && valor > pol.fotoAcimaDe))) throw new Error('Não foi possível pedir o aditivo: ' + (cat === 'OUTRO' ? 'na categoria "Outro"' : 'acima de ' + Via_moeda_(pol.fotoAcimaDe) + ' (política de viagem)') + ' a foto da peça, do orçamento ou o print é obrigatório. Tire a foto e anexe.');
  return Via_comTrava_(function () {
    Via_garantirAbas_(); Adt_garantirAba_(); Adt_memoLimpar_();
    var r = Via_solicitacao_(d.viagemId), mot = Adt_motivoViagem_(eu, r);
    if (mot) throw new Error('Não foi possível pedir o aditivo: ' + mot);
    var ja = Adt_daViagem_(r.ID), igual = ja.filter(function (a) { return ADT_ABERTOS.indexOf(Via_up_(a.SITUACAO)) >= 0 && Via_up_(a.CATEGORIA) === cat && Via_cent_(a.VALOR_PEDIDO) === Via_cent_(valor); })[0];
    if (igual) throw new Error('Não foi possível pedir o aditivo: já há um pedido igual aguardando os sócios (' + Via_s_(igual.NUMERO) + ', ' + Adt_nomeCat_(cat).toLowerCase() + ', ' + Via_moeda_(valor) + '). Para acrescentar informação ou foto, use "Complementar" nele.');
    var seq = ja.reduce(function (m, a) { return Math.max(m, Number(a.SEQ) || 0); }, 0) + 1, numero = Via_s_(r.NUMERO) + '/A' + seq, agora = Via_agora_(), id = Via_id_();
    var anexos = foto ? [Object.assign(Adt_salvarAnexo_(foto, r, numero, 'da foto ou do orçamento'), { por: eu.nome })] : [];
    var c = Via_conteudoDaLinha_(r);
    SGO_DATA.insert(ADT_ABA, { ID: id, NUMERO: numero, ORIGEM_TIPO: 'VIAGEM', ORIGEM_ID: Via_s_(r.ID), ORIGEM_NUMERO: Via_s_(r.NUMERO), SEQ: seq, SOLICITANTE_ID: eu.id, SOLICITANTE_NOME: eu.nome,
      PORTADOR_ID: Via_s_(r.RESPONSAVEL_ID), PORTADOR_NOME: Via_s_(r.RESPONSAVEL_NOME), CATEGORIA: cat, VALOR_PEDIDO: Via_r2_(valor), JUSTIFICATIVA: just, URGENCIA: urg,
      VINCULO_TIPO: Via_s_(c.vinculoTipo), VINCULO_REF: Via_texto_(d.vinculoRef, 120) || Via_s_(r.VINCULO_REF), CLIENTE_ID: Via_s_(r.CLIENTE_ID), CLIENTE_NOME: Via_s_(r.CLIENTE_NOME),
      REPASSAR_CLIENTE: rep, ANEXOS_JSON: JSON.stringify(anexos), COMPLEMENTOS_JSON: '[]', SITUACAO: 'AGUARDANDO', VALOR_APROVADO: '', CARREGADO_TOTAL: 0, MESMA_PESSOA: '',
      ENVIADO_EM: agora, LEMBRETE_EM: '', ESCALADO_EM: '', AVISO_SOCIOS_EM: urg === 'PARADO' || Adt_noExpediente_() ? agora : '', MARCA: Via_marca_([numero, Via_cent_(valor), cat, just, Via_s_(r.RESPONSAVEL_ID)].join('|')), CRIADO_EM: agora, ATUALIZADO_EM: agora });
    Adt_memoLimpar_();
    var a = SGO_DATA.getById(ADT_ABA, id);
    Adt_historico_(a, 'PEDIDO', eu, 'Aditivo de ' + Via_moeda_(valor) + ' (' + Adt_nomeCat_(cat).toLowerCase() + ') pedido por ' + eu.nome + ' para o cartão de ' + Via_s_(r.RESPONSAVEL_NOME) + '. ' + (urg === 'PARADO' ? 'Parado aguardando. ' : '') + 'Para que é: ' + just);
    var socios = Adt_socios_(a, r);
    if (Via_s_(a.AVISO_SOCIOS_EM)) Via_depois_(function () { Adt_avisarEnvio_(a, r, eu); });
    var nomes = Via_nomes_(socios), quando = Adt_hora_(agora), lemb = Adt_hora_(Adt_somarMin_(agora, pol.lembreteMin)), jaAvisou = !!Via_s_(a.AVISO_SOCIOS_EM);
    return { aditivo: Adt_paraTela_(eu, a, r), message: 'Aditivo ' + numero + ' enviado às ' + quando + '. ' + (!nomes.length ? 'Não há sócio disponível para decidir (todos estão nesta viagem): fale com a Diretoria.'
      : jaAvisou ? nomes.join(' e ') + (nomes.length === 1 ? ' foi avisado' : ' foram avisados') + ' por WhatsApp e e-mail' + (urg === 'PARADO' ? ', a qualquer hora' : '') + '. Lembrete automático às ' + lemb + '.'
      : nomes.join(' e ') + ' recebem o aviso na abertura do expediente, porque você marcou que pode ser decidido hoje. Se estiver parado aguardando, cancele e peça de novo marcando "Estou parado aguardando".') + ' Você recebe a decisão aqui e no celular.' };
  });
}
function Adt_exigirPedinte_(eu, a, r, oQue) {
  if (Via_s_(a.SOLICITANTE_ID) !== eu.id && Via_s_(r.SOLICITANTE_ID) !== eu.id) throw new Error('Não foi possível ' + oQue + ': o aditivo ' + Via_s_(a.NUMERO) + ' é de ' + Via_s_(a.SOLICITANTE_NOME) + ' (ou de quem pediu a viagem).');
}
function Adt_cancelar_(eu, d) {
  d = d || {};
  var mot = Via_texto_(d.motivo, 500);
  if (Via_letras_(mot) < 10) throw new Error('Não foi possível cancelar o aditivo: escreva o motivo (10 letras ou mais), por exemplo "a oficina conseguiu consertar sem a peça".');
  return Via_comTrava_(function () {
    Adt_memoLimpar_();
    var a = Adt_doId_(d.id), r = Via_solicitacao_(a.ORIGEM_ID), s = Via_up_(a.SITUACAO);
    Adt_exigirPedinte_(eu, a, r, 'cancelar o aditivo');
    if (ADT_ABERTOS.indexOf(s) < 0 && !(s === 'APROVADO' && !(Number(a.CARREGADO_TOTAL) > 0))) throw new Error('Não foi possível cancelar o aditivo ' + Via_s_(a.NUMERO) + ': ele está "' + (ADT_SITUACOES[s] || s).toLowerCase() + '". ' + (s === 'CARREGADO' || Number(a.CARREGADO_TOTAL) > 0 ? 'O crédito já está no cartão: o que não for gasto volta no acerto da prestação de contas.' : 'Não há o que cancelar.'));
    if (Via_cent_(Via_aCarregar_(r)) < Via_cent_(a.VALOR_APROVADO) && s === 'APROVADO') throw new Error('Não foi possível cancelar o aditivo ' + Via_s_(a.NUMERO) + ': parte da carga do cartão já pode ser dele. Fale com o Financeiro (Wanessa) para conferir antes.');
    var a2 = Adt_atualizar_(a.ID, { SITUACAO: 'CANCELADO', CANCELADO_EM: Via_agora_(), CANCELADO_MOTIVO: mot, CANCELADO_POR_NOME: eu.nome });
    Adt_historico_(a2, 'CANCELADO', eu, 'Cancelado por ' + eu.nome + (s === 'APROVADO' ? ' depois de aprovado e antes da carga' : '') + '. Motivo: ' + mot);
    Via_depois_(function () {
      var ids = Adt_socios_(a2, r).concat(s === 'APROVADO' ? Adt_financeiro_(r) : []);
      Via_notificar_(ids, r, 'Aditivo cancelado: ' + Via_s_(a2.NUMERO), eu.nome + ' cancelou o aditivo ' + Via_s_(a2.NUMERO) + ' (viagem ' + Via_s_(r.NUMERO) + '). Motivo: ' + mot + (s === 'APROVADO' ? '\nNão faça a carga deste aditivo.' : '\nNão há mais decisão a tomar.'), eu.id);
    });
    return { aditivo: Adt_paraTela_(eu, a2, r), message: 'Aditivo ' + Via_s_(a2.NUMERO) + ' cancelado. ' + (s === 'APROVADO' ? 'O Financeiro e os sócios foram avisados para não fazer a carga.' : 'Os sócios foram avisados.') };
  });
}
/** Complementar (texto e foto) enquanto não há decisão; responder ao pedido de informação devolve aos sócios. d: { id, texto, foto }. */
function Adt_complementar_(eu, d) {
  d = d || {};
  var txt = Via_texto_(d.texto, 1500), foto = d.foto && Via_s_(d.foto.base64) ? d.foto : null;
  if (Via_letras_(txt) < 10 && !foto) throw new Error('Não foi possível complementar: escreva a informação (10 letras ou mais) ou anexe a foto. Valor maior pede um aditivo novo.');
  return Via_comTrava_(function () {
    Adt_memoLimpar_();
    var a = Adt_doId_(d.id), r = Via_solicitacao_(a.ORIGEM_ID), s = Via_up_(a.SITUACAO);
    Adt_exigirPedinte_(eu, a, r, 'complementar o aditivo');
    if (ADT_ABERTOS.indexOf(s) < 0) throw new Error('Não foi possível complementar: o aditivo ' + Via_s_(a.NUMERO) + ' já foi decidido (' + (ADT_SITUACOES[s] || s).toLowerCase() + ').');
    var comps = Via_json_(a.COMPLEMENTOS_JSON, []), anexos = Via_json_(a.ANEXOS_JSON, []), agora = Via_agora_();
    if (foto) anexos.push(Object.assign(Adt_salvarAnexo_(foto, r, Via_s_(a.NUMERO), 'da foto ou do orçamento'), { por: eu.nome }));
    comps.push({ texto: txt, foto: foto ? anexos[anexos.length - 1].nome : '', por: eu.nome, em: agora, respostaInfo: s === 'INFORMACAO' });
    var campos = { COMPLEMENTOS_JSON: JSON.stringify(comps), ANEXOS_JSON: JSON.stringify(anexos) };
    if (s === 'INFORMACAO') Object.assign(campos, { SITUACAO: 'AGUARDANDO', AVISO_SOCIOS_EM: agora, LEMBRETE_EM: '', ESCALADO_EM: '' });
    var a2 = Adt_atualizar_(a.ID, campos);
    Adt_historico_(a2, s === 'INFORMACAO' ? 'INFORMACAO_RESPONDIDA' : 'COMPLEMENTADO', eu, (s === 'INFORMACAO' ? 'Resposta ao pedido de informação: ' : 'Complemento: ') + (txt || '(só a foto)') + (foto ? ' Foto: ' + anexos[anexos.length - 1].nome + '.' : ''));
    Via_depois_(function () { Adt_avisarSocios_(a2, r, eu, (s === 'INFORMACAO' ? 'Resposta de ' : 'Complemento de ') + eu.nome + ': ' + (txt || 'foto anexada') + '.', 'C' + comps.length); });
    return { aditivo: Adt_paraTela_(eu, a2, r), message: s === 'INFORMACAO' ? 'Resposta enviada: o aditivo ' + Via_s_(a2.NUMERO) + ' voltou para os sócios, que foram avisados.' : 'Complemento gravado e enviado aos sócios.' };
  });
}
/** Parecer do gestor da área (acompanha, não trava). d: { id, parecer (CONFIRMO | NAO_VEJO), texto }. */
function Adt_parecer_(eu, d) {
  d = d || {};
  var p = Via_up_(d.parecer), txt = Via_texto_(d.texto, 800);
  if (!ADT_PARECERES[p]) throw new Error('Não foi possível registrar o parecer: escolha "Confirmo que é necessário" ou "Não vejo necessidade".');
  if (p === 'NAO_VEJO' && Via_letras_(txt) < ADT_MOTIVO_MIN) throw new Error('Não foi possível registrar o parecer: diga por que não vê necessidade (' + ADT_MOTIVO_MIN + ' letras ou mais). Os sócios leem antes de decidir.');
  return Via_comTrava_(function () {
    Adt_memoLimpar_();
    var a = Adt_doId_(d.id), r = Via_solicitacao_(a.ORIGEM_ID);
    if (Adt_gestores_(a, r).indexOf(eu.id) < 0) throw new Error('Não foi possível registrar o parecer: ele é do gestor da área de quem pediu o aditivo (Regras e responsáveis da Caixa de decisões). Os sócios decidem direto no aditivo.');
    if (ADT_ABERTOS.indexOf(Via_up_(a.SITUACAO)) < 0) throw new Error('Não foi possível registrar o parecer: o aditivo ' + Via_s_(a.NUMERO) + ' já foi decidido.');
    var a2 = Adt_atualizar_(a.ID, { PARECER_GESTOR: p, PARECER_TEXTO: txt, PARECER_POR_ID: eu.id, PARECER_POR_NOME: eu.nome, PARECER_EM: Via_agora_() });
    Adt_historico_(a2, 'PARECER', eu, 'Parecer do gestor ' + eu.nome + ': ' + ADT_PARECERES[p] + (txt ? '. ' + txt : '.'));
    Via_depois_(function () { Via_notificar_(Adt_socios_(a2, r), r, 'Parecer do gestor no aditivo ' + Via_s_(a2.NUMERO), eu.nome + ' (gestor da área) registrou: ' + ADT_PARECERES[p] + (txt ? '. ' + txt : '.') + '\nO parecer não trava: a decisão continua com os sócios.', eu.id); });
    return { aditivo: Adt_paraTela_(eu, a2, r), message: 'Parecer registrado. Ele aparece para os sócios na hora de decidir; a decisão continua com eles.' };
  });
}

// ------------------------------------------------------------
// DECISÃO DOS SÓCIOS
// ------------------------------------------------------------
/** d: { id, decisao (APROVAR | INFO | NEGAR), valor (opcional, menor ou igual ao pedido), fundamentacao }. */
function Adt_decidir_(eu, d) {
  d = d || {};
  var dec = Via_up_(d.decisao), fund = Via_texto_(d.fundamentacao, 1500), valorD = Via_s_(d.valor) === '' ? null : Via_num_(d.valor);
  if (['APROVAR', 'INFO', 'NEGAR'].indexOf(dec) < 0) throw new Error('Não foi possível decidir: escolha Aprovar, Pedir informação ou Negar.');
  if (dec === 'NEGAR' && Via_letras_(fund) < ADT_MOTIVO_MIN) throw new Error('Não foi possível negar: escreva o motivo (' + ADT_MOTIVO_MIN + ' letras ou mais). Ele vai para quem pediu, que está esperando a resposta.');
  if (dec === 'INFO' && Via_letras_(fund) < 10) throw new Error('Não foi possível pedir informação: escreva o que falta (10 letras ou mais), por exemplo "mande a foto do orçamento da oficina".');
  var saida = Via_comTrava_(function () {
    Via_garantirAbas_(); Adt_memoLimpar_();
    var a = Adt_doId_(d.id), r = Via_solicitacao_(a.ORIGEM_ID), s = Via_up_(a.SITUACAO);
    if (ADT_ABERTOS.indexOf(s) < 0) throw new Error('Não foi possível decidir: o aditivo ' + Via_s_(a.NUMERO) + ' já está "' + (ADT_SITUACOES[s] || s).toLowerCase() + '"' + (Via_s_(a.DECIDIDO_POR_NOME) ? ' (' + Via_s_(a.DECIDIDO_POR_NOME) + ')' : '') + '. Atualize a tela.');
    if (!Adt_ehSocio_(eu)) throw new Error('Não foi possível decidir: o aditivo de recarga é decidido por um dos sócios (o dono ou a Diretoria), pela regra do Financeiro (toda saída de dinheiro só pelos sócios). Você pode acompanhar por aqui.');
    if (Adt_conflito_(a, r).indexOf(eu.id) >= 0) throw new Error('Não foi possível decidir: você ' + (Via_s_(a.SOLICITANTE_ID) === eu.id ? 'pediu este aditivo' : 'está nesta viagem') + ', e ninguém aprova a própria despesa. O outro sócio decide.');
    var agora = Via_agora_(), pedido = Number(a.VALOR_PEDIDO) || 0, campos = { DECIDIDO_POR_ID: eu.id, DECIDIDO_POR_NOME: eu.nome, DECIDIDO_EM: agora, FUNDAMENTACAO: fund }, valor = pedido, lib = null;
    if (dec === 'APROVAR') {
      if (valorD !== null) {
        if (!(valorD > 0)) throw new Error('Não foi possível aprovar: o valor aprovado precisa ser maior que zero. Para não liberar nada, use Negar.');
        if (Via_cent_(valorD) > Via_cent_(pedido)) throw new Error('Não foi possível aprovar: ' + Via_moeda_(valorD) + ' é maior que o pedido (' + Via_moeda_(pedido) + '). Valor maior pede um aditivo novo de quem está na viagem.');
        valor = Via_r2_(valorD);
      }
      if (Via_cent_(valor) < Via_cent_(pedido) && Via_letras_(fund) < ADT_MOTIVO_MIN) throw new Error('Não foi possível aprovar com valor menor: escreva a fundamentação (' + ADT_MOTIVO_MIN + ' letras ou mais), para quem pediu entender o que fica de fora.');
      Object.assign(campos, { SITUACAO: 'APROVADO', VALOR_APROVADO: valor, FUNDAMENTACAO: fund || 'Aprovado.' });
      // trava de prestação vencida do responsável pelo dinheiro: aprovar registra também a liberação para esta viagem (2 dias)
      var tv = typeof Via_vencidasDe_ === 'function' ? Via_vencidasDe_(Via_s_(r.RESPONSAVEL_ID), Via_s_(r.ID)) : [];
      if (tv.length && typeof Via_liberacaoDe_ === 'function' && !Via_liberacaoDe_(Via_s_(r.RESPONSAVEL_ID), tv.map(function (x) { return Via_s_(x.r.ID); }))) {
        lib = { ID: Via_id_(), PESSOA_ID: Via_s_(r.RESPONSAVEL_ID), PESSOA_NOME: Via_s_(r.RESPONSAVEL_NOME), SOLICITACOES_JSON: JSON.stringify(tv.map(function (x) { return Via_s_(x.r.ID); })),
          NUMEROS: tv.map(function (x) { return Via_s_(x.r.NUMERO); }).join(', '), MOTIVO: 'Aprovação do aditivo ' + Via_s_(a.NUMERO) + ' (viagem em andamento) por ' + eu.nome + '. ' + (fund || 'Aprovado.'), VALIDA_ATE: Via_somarDias_(Via_hoje_(), 2), POR_ID: eu.id, POR_NOME: eu.nome, EM: agora };
        SGO_DATA.insert(VIA_ABAS.LIBERACOES, lib);
        campos.LIBERACAO_ID = lib.ID;
      }
    } else if (dec === 'INFO') Object.assign(campos, { SITUACAO: 'INFORMACAO', INFO_PEDIDA: fund, INFO_PEDIDA_POR_NOME: eu.nome, INFO_PEDIDA_EM: agora, DECIDIDO_POR_ID: '', DECIDIDO_POR_NOME: '', DECIDIDO_EM: '', FUNDAMENTACAO: '' });
    else Object.assign(campos, { SITUACAO: 'NEGADO' });
    var a2 = Adt_atualizar_(a.ID, campos);
    Adt_historico_(a2, dec === 'APROVAR' ? 'APROVADO' : dec === 'INFO' ? 'INFORMACAO_PEDIDA' : 'NEGADO', eu,
      dec === 'APROVAR' ? 'Aprovado por ' + eu.nome + ': ' + Via_moeda_(valor) + (Via_cent_(valor) < Via_cent_(pedido) ? ' (pedido ' + Via_moeda_(pedido) + ')' : '') + '. ' + (fund || '') + (lib ? ' Liberação da trava de prestação vencida (' + lib.NUMEROS + ') até ' + Via_brDia_(lib.VALIDA_ATE) + '.' : '') + ' A aprovação da viagem não muda; o valor soma ao teto de carga.'
        : dec === 'INFO' ? 'Pedido de informação de ' + eu.nome + ': ' + fund : 'Negado por ' + eu.nome + '. Motivo: ' + fund);
    if (lib) Via_historico_('SOLICITACAO', Via_s_(r.ID), 'TRAVA_LIBERADA', eu, { texto: 'Liberação da trava (prestação vencida: ' + lib.NUMEROS + ') registrada com a aprovação do aditivo ' + Via_s_(a2.NUMERO) + ', até ' + Via_brDia_(lib.VALIDA_ATE) + '.' });
    var r2 = SGO_DATA.getById(VIA_ABAS.SOLICITACOES, r.ID);
    Via_depois_(function () { Adt_avisarDecisao_(a2, r2, eu, dec); });
    return { a: a2, r: r2, dec: dec, valor: valor };
  });
  var a3 = saida.a, m = saida.dec === 'APROVAR' ? 'Aditivo ' + Via_s_(a3.NUMERO) + ' aprovado (' + Via_moeda_(saida.valor) + '). ' + Via_s_(a3.SOLICITANTE_NOME) + ' foi avisado na hora; o Financeiro recebeu a carga a fazer. Se ninguém do Financeiro puder carregar agora, o outro sócio registra a carga no próprio aditivo.'
    : saida.dec === 'INFO' ? 'Pedido de informação enviado a ' + Via_s_(a3.SOLICITANTE_NOME) + '. O aditivo volta para você quando ele responder.' : 'Aditivo ' + Via_s_(a3.NUMERO) + ' negado. ' + Via_s_(a3.SOLICITANTE_NOME) + ' foi avisado com o motivo.';
  return { aditivo: Adt_paraTela_(eu, a3, saida.r), message: m };
}

// ------------------------------------------------------------
// CARGA DO ADITIVO (caminho de exceção: sócio, ou o aprovador fora do expediente)
// ------------------------------------------------------------
/** O que falta carregar deste aditivo (a carga da viagem cobre primeiro a recarga aprovada, depois os aditivos pela ordem da aprovação). */
function Adt_alocacao_(r) {
  var disp = Via_r2_((Number(r.CARREGADO_TOTAL) || 0) - (typeof Via_recargaAprovada_ === 'function' ? Via_recargaAprovada_(r) : Number(r.APROVADO_TOTAL) || 0)), out = {};
  Adt_daViagem_(r.ID).filter(function (a) { return Adt_aprovadoValor_(a) > 0; }).sort(function (a, b) { return Via_s_(a.DECIDIDO_EM).localeCompare(Via_s_(b.DECIDIDO_EM)); }).forEach(function (a) {
    var v = Adt_aprovadoValor_(a), cob = Math.max(0, Math.min(v, disp));
    disp = Via_r2_(disp - v);
    out[Via_s_(a.ID)] = { aprovado: v, carregado: Via_r2_(cob), falta: Via_r2_(v - cob) };
  });
  return out;
}
function Adt_acoesCarga_(eu, a, r) {
  var nao = function (m) { return { pode: false, motivo: m }; };
  if (Via_up_(a.SITUACAO) !== 'APROVADO') return nao('Só aditivo aprovado e ainda não carregado.');
  var al = Adt_alocacao_(r)[Via_s_(a.ID)] || { falta: 0 };
  if (!(al.falta > 0)) return nao('O valor deste aditivo já está carregado.');
  if (['APROVADA', 'CARGA_FEITA'].indexOf(Via_up_(r.SITUACAO)) < 0) return nao('A viagem não aceita mais carga (' + (VIA_SITUACOES[Via_up_(r.SITUACAO)] || r.SITUACAO).toLowerCase() + '): o gasto entra na prestação e vira reembolso.');
  if (Via_equipeIds_(r).indexOf(eu.id) >= 0) return nao('Você viaja nesta viagem: a carga do próprio cartão é feita por outra pessoa.');
  if (typeof Cju_pedidoEmAndamentoDe_ === 'function' && Cju_pedidoEmAndamentoDe_(r.ID)) return nao('Há um pedido de crédito no Caju em andamento nesta viagem: espere o crédito ou cancele o pedido.');
  var socio = Adt_ehSocio_(eu), fin = Via_pode_(eu, 'VIAGEM_DEPOSITAR'), aprovador = Via_s_(a.DECIDIDO_POR_ID) === eu.id;
  if (!socio && !fin) return nao('A carga é do Financeiro (caixa «' + Via_nomeCaixa_('VIAGEM_DEPOSITAR') + '») ou, fora do expediente, de um dos sócios.');
  if (!aprovador) return { pode: true, motivo: '', falta: al.falta, excecao: false };
  var ex = typeof SGO_dentroDoExpediente_ === 'function' ? SGO_dentroDoExpediente_(new Date()) : { dentro: true };
  if (ex.dentro) return nao('Você aprovou este aditivo: no expediente, a carga é do Financeiro (Wanessa) ou do outro sócio (separação de funções).');
  return { pode: true, motivo: '', falta: al.falta, excecao: true, aviso: 'Você aprovou este aditivo. Fora do expediente, se nem o Financeiro nem o outro sócio puderem carregar, registre a carga como EXCEÇÃO, com o motivo: a Wanessa confere no próximo dia útil.' };
}
/** d: { id, valor (padrão: o que falta), data, comprovante, observacao, excecaoMotivo }. */
function Adt_registrarCarga_(eu, d) {
  d = d || {};
  var data = Via_dia_(d.data) || Via_hoje_(), obs = Via_texto_(d.observacao, 600), excMot = Via_texto_(d.excecaoMotivo, 600);
  if (data > Via_hoje_()) throw new Error('Não foi possível registrar a carga: a data (' + Via_brDia_(data) + ') é futura. Registre depois de fazer a carga no portal do Caju.');
  if (!d.comprovante || !Via_s_(d.comprovante.base64)) throw new Error('Não foi possível registrar a carga: anexe o comprovante da carga (print da tela ou recibo do portal do Caju).');
  var saida = Via_comTrava_(function () {
    Via_garantirAbas_(); Adt_memoLimpar_();
    var a = Adt_doId_(d.id), r = Via_solicitacao_(a.ORIGEM_ID), ac = Adt_acoesCarga_(eu, a, r);
    if (!ac.pode) throw new Error('Não foi possível registrar a carga do aditivo ' + Via_s_(a.NUMERO) + ': ' + ac.motivo);
    if (ac.excecao && Via_letras_(excMot) < ADT_MOTIVO_MIN) throw new Error('Não foi possível registrar a carga: você aprovou este aditivo, então a carga por você é exceção. Escreva o motivo (' + ADT_MOTIVO_MIN + ' letras ou mais), por exemplo "Financeiro fora do expediente e o outro sócio sem acesso ao portal; técnico parado no cliente".');
    var valor = Via_s_(d.valor) === '' ? ac.falta : Via_num_(d.valor), teto = Via_aCarregar_(r);
    if (valor === null || !(valor > 0)) throw new Error('Não foi possível registrar a carga: informe o valor carregado (maior que zero).');
    if (Via_cent_(valor) > Via_cent_(ac.falta) || Via_cent_(valor) > Via_cent_(teto)) throw new Error('Não foi possível registrar a carga: ' + Via_moeda_(valor) + ' passa do que falta carregar deste aditivo (' + Via_moeda_(Math.min(ac.falta, teto)) + '). Carga acima do aprovado só com novo aditivo.');
    if (Via_cent_(valor) < Via_cent_(ac.falta) && Via_letras_(obs) < 10) throw new Error('Não foi possível registrar a carga: o valor é menor que o que falta (' + Via_moeda_(ac.falta) + '). Escreva na observação por que a carga é parcial (10 letras ou mais).');
    if (typeof Via_travaPrestacao_ === 'function') { var tv = Via_travaPrestacao_(Via_s_(r.RESPONSAVEL_ID), Via_s_(r.ID)); if (tv) throw new Error('Não foi possível registrar a carga: ' + tv.texto); }
    var arq = Via_salvarArquivo_(d.comprovante, Via_s_(r.NUMERO), 'Comprovante da carga do aditivo ' + Via_s_(a.NUMERO).replace(/^.*\//, ''), 'do comprovante da carga');
    var agora = Via_agora_(), anexoId = Via_id_(), cargaId = Via_id_(), centro = typeof Via_centroCaju_ === 'function' ? Via_centroCaju_(r) : Via_s_(r.CENTRO_CUSTO_CODIGO);
    SGO_DATA.insert(VIA_ABAS.ANEXOS, { ID: anexoId, SOLICITACAO_ID: r.ID, LINHA_ID: '', CATEGORIA: '', TIPO: 'COMPROVANTE_CARGA', NOME: arq.nome, ARQUIVO_ID: arq.id, URL: arq.url, MIME: Via_s_(d.comprovante.tipo),
      TAMANHO: arq.tamanho, SHA: arq.sha, ENVIADO_POR_ID: eu.id, ENVIADO_POR_NOME: eu.nome, ENVIADO_EM: agora });
    SGO_DATA.insert(VIA_ABAS.CARGAS, { ID: cargaId, SOLICITACAO_ID: r.ID, REVISAO: r.APROVADO_REVISAO, DATA: data, VALOR: Via_r2_(valor), CENTRO_CUSTO_CAJU: centro,
      OBSERVACAO: 'Carga do aditivo ' + Via_s_(a.NUMERO) + (ac.excecao ? ' (EXCEÇÃO: registrada por quem aprovou; motivo: ' + excMot + ')' : '') + (obs ? '. ' + obs : ''), COMPROVANTE_ID: anexoId, COMPROVANTE_URL: arq.url,
      COMPROVANTE_NOME: arq.nome, POR_ID: eu.id, POR_NOME: eu.nome, EM: agora, EXTRATO_ID: '', CONCILIADA_EM: '', ORIGEM: 'ADITIVO', ADITIVO_ID: Via_s_(a.ID), MESMA_PESSOA: ac.excecao ? 'SIM' : '' });
    var novoTotal = Via_r2_((Number(r.CARREGADO_TOTAL) || 0) + valor), campos = { CARREGADO_TOTAL: novoTotal, SITUACAO: 'CARGA_FEITA', ATUALIZADO_EM: agora, ATUALIZADO_POR_NOME: eu.nome };
    if (!Via_s_(r.PRESTACAO_PRAZO) && typeof Via_prazoCalcular_ === 'function') { campos.PRESTACAO_PRAZO = Via_prazoCalcular_(r.CHEGADA_EM); campos.PRESTACAO_SITUACAO = 'EM_ABERTO'; }
    SGO_DATA.update(VIA_ABAS.SOLICITACOES, r.ID, campos);
    Via_historico_('SOLICITACAO', r.ID, 'CARGA_REGISTRADA', eu, { revisao: r.APROVADO_REVISAO, de: VIA_SITUACOES[Via_up_(r.SITUACAO)], para: VIA_SITUACOES.CARGA_FEITA,
      texto: 'Carga de ' + Via_moeda_(valor) + ' em ' + Via_brDia_(data) + ' no cartão Caju, do aditivo ' + Via_s_(a.NUMERO) + (ac.excecao ? ' (EXCEÇÃO: por quem aprovou o aditivo; a Wanessa confere no próximo dia útil. Motivo: ' + excMot + ')' : '') + '. Carregado: ' + Via_moeda_(novoTotal) + ' de ' + Via_moeda_(Via_tetoCarga_(r)) + '.' });
    if (ac.excecao) Adt_atualizar_(a.ID, { MESMA_PESSOA: 'SIM', EXCECAO_MOTIVO: excMot, EXCECAO_POR_NOME: eu.nome });
    var r2 = SGO_DATA.getById(VIA_ABAS.SOLICITACOES, r.ID);
    Adt_aposCarga_(r2, eu, cargaId);
    return { a: SGO_DATA.getById(ADT_ABA, a.ID), r: r2, valor: valor, excecao: ac.excecao };
  });
  return { aditivo: Adt_paraTela_(eu, saida.a, saida.r), message: 'Carga de ' + Via_moeda_(saida.valor) + ' do aditivo ' + Via_s_(saida.a.NUMERO) + ' registrada com o comprovante.' + (saida.excecao ? ' Ficou marcada como exceção (registrada por quem aprovou): a Wanessa confere no próximo dia útil.' : '') + ' ' + Via_s_(saida.a.PORTADOR_NOME) + ' foi avisado do crédito.' };
}
/**
 * Depois de qualquer carga na viagem (manual, pelo Caju ou pelo aditivo): marca como carregados os aditivos cobertos pela carga e avisa
 * quem pediu e o portador do crédito. Chamado de Via_registrarCarga_, Cju_pedidoPagar_ e Adt_registrarCarga_ (dentro da trava). Nunca lança.
 */
function Adt_aposCarga_(r, quem, cargaId) {
  try {
    Adt_memoLimpar_();
    var al = Adt_alocacao_(r), agora = Via_agora_(), feitos = [];
    Adt_daViagem_(r.ID).forEach(function (a) {
      var x = al[Via_s_(a.ID)];
      if (!x) return;
      var campos = {};
      if (Via_cent_(x.carregado) !== Via_cent_(a.CARREGADO_TOTAL)) campos.CARREGADO_TOTAL = x.carregado;
      if (Via_up_(a.SITUACAO) === 'APROVADO' && !(x.falta > 0)) { campos.SITUACAO = 'CARREGADO'; campos.CARREGADO_EM = agora; campos.CARGA_ID = Via_s_(cargaId); feitos.push(a); }
      if (Object.keys(campos).length) Adt_atualizar_(a.ID, campos);
    });
    if (cargaId && feitos.length) { try { SGO_DATA.update(VIA_ABAS.CARGAS, Via_s_(cargaId), { ADITIVO_ID: feitos.map(function (a) { return Via_s_(a.ID); }).join(',') }); } catch (e1) {} }
    feitos.forEach(function (a) {
      Adt_historico_(a, 'CARREGADO', quem || { id: '', nome: 'sistema' }, 'Valor do aditivo (' + Via_moeda_(a.VALOR_APROVADO) + ') carregado no cartão Caju de ' + Via_s_(a.PORTADOR_NOME) + '.');
      Via_depois_(function () { Adt_avisarPedinte_(a, r, 'Crédito do aditivo ' + Via_s_(a.NUMERO) + ' no seu cartão Caju', 'O crédito de ' + Via_moeda_(a.VALOR_APROVADO) + ' do aditivo ' + Via_s_(a.NUMERO) + ' está disponível no cartão Caju de ' + Via_s_(a.PORTADOR_NOME) + '.\nGuarde o comprovante: na prestação de contas da viagem, marque o gasto com o aditivo ' + Via_s_(a.NUMERO).replace(/^.*\//, '') + '.', 'CARGA'); });
    });
    return feitos.length;
  } catch (e) { console.error('Aditivo de recarga (depois da carga): ' + Via_erro_(e)); return 0; }
}
/** Pedido de crédito pelo Caju (SGO_Caju_Pedidos.js): se o que falta carregar é só de aditivos, o pedido leva o número do primeiro. */
function Adt_pendenteCaju_(r) {
  try {
    var base = typeof Via_recargaAprovada_ === 'function' ? Via_recargaAprovada_(r) : Number(r.APROVADO_TOTAL) || 0;
    if (Via_cent_(r.CARREGADO_TOTAL) < Via_cent_(base)) return null;
    var al = Adt_alocacao_(r), pend = Adt_daViagem_(r.ID).filter(function (a) { return (al[Via_s_(a.ID)] || {}).falta > 0; });
    return pend.length ? { numero: Via_s_(pend[0].NUMERO), ids: pend.map(function (a) { return Via_s_(a.ID); }) } : null;
  } catch (e) { return null; }
}
/** Conferência da carga feita como exceção pelo aprovador (Financeiro, no dia útil seguinte). d: { id, texto }. */
function Adt_conferirExcecao_(eu, d) {
  d = d || {};
  var txt = Via_texto_(d.texto, 600);
  return Via_comTrava_(function () {
    Adt_memoLimpar_();
    var a = Adt_doId_(d.id), r = Via_solicitacao_(a.ORIGEM_ID);
    if (Via_up_(a.MESMA_PESSOA) !== 'SIM' || Via_s_(a.EXCECAO_CONFERIDA_EM)) throw new Error('Não foi possível conferir: o aditivo ' + Via_s_(a.NUMERO) + ' não tem carga de exceção a conferir.');
    if (!Via_pode_(eu, 'VIAGEM_CONFERIR') && !Via_pode_(eu, 'VIAGEM_DEPOSITAR')) throw new Error('Não foi possível conferir: a conferência da carga de exceção é do Financeiro (caixa «' + Via_nomeCaixa_('VIAGEM_CONFERIR') + '»).');
    if (Via_s_(a.DECIDIDO_POR_ID) === eu.id || Via_equipeIds_(r).indexOf(eu.id) >= 0) throw new Error('Não foi possível conferir: você aprovou o aditivo ou está na viagem. A conferência é de outra pessoa do Financeiro.');
    var a2 = Adt_atualizar_(a.ID, { EXCECAO_CONFERIDA_EM: Via_agora_(), EXCECAO_CONFERIDA_POR_NOME: eu.nome, EXCECAO_CONFERIDA_TEXTO: txt || 'Conferida: comprovante e valor batem com o aditivo aprovado.' });
    Adt_historico_(a2, 'EXCECAO_CONFERIDA', eu, 'Carga de exceção (registrada por ' + Via_s_(a.EXCECAO_POR_NOME) + ') conferida por ' + eu.nome + '. ' + (txt || 'Comprovante e valor batem com o aditivo aprovado.'));
    return { aditivo: Adt_paraTela_(eu, a2, r), message: 'Carga de exceção do aditivo ' + Via_s_(a2.NUMERO) + ' conferida.' };
  });
}
/** Repasse ao cliente tratado (Comercial ou Financeiro): incluído no faturamento ou no orçamento do chamado. d: { id, texto }. */
function Adt_repasse_(eu, d) {
  d = d || {};
  var txt = Via_texto_(d.texto, 600);
  if (Via_letras_(txt) < 10) throw new Error('Não foi possível registrar: escreva como o repasse foi tratado (10 letras ou mais), por exemplo "incluído no orçamento do chamado CH-2026-0040".');
  return Via_comTrava_(function () {
    Adt_memoLimpar_();
    var a = Adt_doId_(d.id), r = Via_solicitacao_(a.ORIGEM_ID);
    if (Via_up_(a.REPASSAR_CLIENTE) !== 'SIM' || Adt_aprovadoValor_(a) <= 0 || Via_s_(a.REPASSE_TRATADO_EM)) throw new Error('Não foi possível registrar: o aditivo ' + Via_s_(a.NUMERO) + ' não tem repasse ao cliente pendente.');
    if (Adt_repassadores_(a, r).indexOf(eu.id) < 0 && !Adt_ehSocio_(eu)) throw new Error('Não foi possível registrar: o repasse ao cliente é tratado pela gestão do Comercial ou pelo Financeiro.');
    var a2 = Adt_atualizar_(a.ID, { REPASSE_TRATADO_EM: Via_agora_(), REPASSE_TRATADO_POR_NOME: eu.nome, REPASSE_TEXTO: txt });
    Adt_historico_(a2, 'REPASSE_TRATADO', eu, 'Repasse ao cliente tratado por ' + eu.nome + ': ' + txt);
    return { aditivo: Adt_paraTela_(eu, a2, r), message: 'Repasse ao cliente registrado no aditivo ' + Via_s_(a2.NUMERO) + '.' };
  });
}
/** Quem trata o repasse ao cliente: gestão do Comercial e o Financeiro (conferência). */
function Adt_repassadores_(a, r) {
  var ids = [];
  try { if (typeof SGO_avisoGestoresDe_ === 'function') ids = SGO_avisoGestoresDe_('comercial', { area: 'COMERCIAL', excluir: Via_conflito_(r) }) || []; } catch (e) { ids = []; }
  try { (Via_comPapel_('VIAGEM_CONFERIR', Via_conflito_(r)) || []).forEach(function (id) { if (ids.indexOf(id) < 0) ids.push(id); }); } catch (e2) {}
  return ids;
}

// ------------------------------------------------------------
// AVISOS (GS12 pela fila da gestão; VG01 a quem pediu)
// ------------------------------------------------------------
function Adt_registrarAvisos_() {
  try {
    var ev = { cod: ADT_EVENTO_GESTAO, modulo: VIA_MODULO, evento: 'Aditivo de recarga em viagem: pedido aos sócios, lembrete de 30 minutos, tarefa de 60 minutos (Financeiro e gestor), aprovação ao Financeiro', origem: 'SGO_Caju_Aditivo.js',
      publico: 'Sócios (dono e Diretoria), menos quem pediu ou viaja; gestor da área de quem pediu (acompanha); Financeiro (carga)', email: 'NAO', whatsapp: 'NAO', limite: '1 por aviso por pessoa',
      obs: 'Aviso da gestão: e-mail e WhatsApp (modelo sgo_gestao_acao). Quem está parado aguardando: aos sócios a qualquer hora; senão no expediente. Gestor e Financeiro no expediente (o Financeiro na hora quando parado). Nada é aprovado por tempo.', gestao: 'PENDENCIA' };
    if (typeof AVG_MTZ_EVENTOS !== 'undefined' && Array.isArray(AVG_MTZ_EVENTOS) && !AVG_MTZ_EVENTOS.some(function (x) { return x && x.cod === ADT_EVENTO_GESTAO; })) AVG_MTZ_EVENTOS.push(ev);
    [typeof AVG_NA_HORA_EVENTOS !== 'undefined' ? AVG_NA_HORA_EVENTOS : null, typeof AVG_NA_HORA_PEDIDOS !== 'undefined' ? AVG_NA_HORA_PEDIDOS : null]
      .forEach(function (l) { if (Array.isArray(l) && l.indexOf(ADT_EVENTO_GESTAO) < 0) l.push(ADT_EVENTO_GESTAO); });
    if (typeof AVG_APROVACOES !== 'undefined' && Array.isArray(AVG_APROVACOES) && AVG_APROVACOES.indexOf('aditivo_decidir') < 0) AVG_APROVACOES.push('aditivo_decidir');
    if (typeof MTZ_PADRAO !== 'undefined' && Array.isArray(MTZ_PADRAO) && !MTZ_PADRAO.some(function (x) { return x && x.cod === ADT_EVENTO_PEDINTE; })) {
      MTZ_PADRAO.push({ cod: ADT_EVENTO_PEDINTE, modulo: VIA_MODULO, evento: 'Aditivo de recarga em viagem: decisão dos sócios, pedido de informação e crédito no cartão (a quem pediu e ao portador)', origem: 'SGO_Caju_Aditivo.js',
        publico: 'Quem pediu o aditivo e o responsável pelo dinheiro da viagem', email: 'HORA', whatsapp: 'HORA', limite: 'Parado aguardando: na hora, a qualquer horário; senão, regra do expediente',
        obs: 'Resposta a um pedido da própria pessoa (não é cobrança). Quem marcou "estou parado aguardando" recebe na hora, a qualquer horário (estudo de 19/11/2026, seção 2.5); os demais, no expediente.', whatsHoraPermitido: true, obrigatorio: true });
    }
  } catch (e) { try { console.error('Aditivo de recarga, registro dos avisos: ' + Via_erro_(e)); } catch (x) {} }
}
function Adt_resumo_(a, r, comValor) {
  var parecer = Via_s_(a.PARECER_GESTOR) ? '\nParecer do gestor (' + Via_s_(a.PARECER_POR_NOME) + '): ' + (ADT_PARECERES[Via_up_(a.PARECER_GESTOR)] || '') + (Via_s_(a.PARECER_TEXTO) ? '. ' + Via_s_(a.PARECER_TEXTO) : '') : '';
  var tv = typeof Via_vencidasDe_ === 'function' ? Via_vencidasDe_(Via_s_(r.RESPONSAVEL_ID), Via_s_(r.ID)) : [];
  return 'Aditivo ' + Via_s_(a.NUMERO) + ' (viagem ' + Via_s_(r.NUMERO) + ', ' + Via_s_(r.DESTINO_CIDADE) + '/' + Via_up_(r.DESTINO_UF) + (Via_s_(r.CLIENTE_NOME) ? ', cliente ' + Via_s_(r.CLIENTE_NOME) : '') + ').\n' +
    'Pedido por ' + Via_s_(a.SOLICITANTE_NOME) + ' para o cartão de ' + Via_s_(a.PORTADOR_NOME) + ': ' + Adt_nomeCat_(a.CATEGORIA) + (comValor ? ', ' + Via_moeda_(a.VALOR_PEDIDO) : '') + '.\n' +
    'Para que é: ' + Via_s_(a.JUSTIFICATIVA) + (Via_up_(a.URGENCIA) === 'PARADO' ? '\nESTÁ PARADO AGUARDANDO A DECISÃO.' : '') + (Via_s_(a.VINCULO_REF) ? '\nVínculo: ' + Via_s_(a.VINCULO_REF) + '.' : '') +
    '\nRepassar ao cliente: ' + (ADT_REPASSAR[Via_up_(a.REPASSAR_CLIENTE)] || 'A definir').toLowerCase() + '.' + parecer +
    (tv.length ? '\nAtenção: ' + Via_s_(r.RESPONSAVEL_NOME) + ' tem prestação de contas vencida (' + tv.map(function (x) { return Via_s_(x.r.NUMERO); }).join(', ') + '). Aprovar registra também a liberação da trava para esta viagem.' : '');
}
/** Pedido aos sócios (GS12, a qualquer hora quando parado) e ao gestor da área (acompanha, sem botão de decisão). Nunca lança. */
function Adt_avisarEnvio_(a, r, eu) {
  try {
    Adt_registrarAvisos_();
    var urg = Via_up_(a.URGENCIA) === 'PARADO', socios = Adt_socios_(a, r), refId = 'ADT:DEC:' + Via_s_(a.ID);
    var titulo = (urg ? 'URGENTE · parado aguardando · ' : '') + 'Aditivo de recarga ' + Via_s_(a.NUMERO) + ': ' + Adt_nomeCat_(a.CATEGORIA) + ', ' + Via_moeda_(a.VALOR_PEDIDO) + ', pedido de ' + Via_s_(a.SOLICITANTE_NOME);
    var texto = Adt_resumo_(a, r, true) + '\nDecida no SGO+ (Depósito de viagem > Aditivos de recarga): aprove, aprove com valor menor, peça informação ou negue. Basta um sócio.';
    Adt_gestaoNaHora_(socios, a, r, eu, refId, 'P' + Via_s_(a.ENVIADO_EM), titulo, texto, urg, true);
    var gest = Adt_gestores_(a, r);
    if (gest.length) {
      var us = Via_usuarios_(), comV = gest.filter(function (id) { return us[id] && Via_podeVer_(Object.assign({}, us[id], { sessao: null }), r); }), semV = gest.filter(function (id) { return comV.indexOf(id) < 0; });
      var tg = function (v) { return 'Para acompanhar: ' + Via_s_(a.SOLICITANTE_NOME) + ' pediu um aditivo de recarga em viagem. ' + Adt_resumo_(a, r, v) + '\nA decisão é dos sócios. Se quiser, registre o seu parecer no SGO+ (Depósito de viagem > Aditivos de recarga): "confirmo que é necessário" ou "não vejo necessidade, porque...". O parecer não trava.'; };
      if (comV.length) Adt_gestaoNaHora_(comV, a, r, eu, 'ADT:PAR:' + Via_s_(a.ID), 'G' + Via_s_(a.ENVIADO_EM), 'Para acompanhar · aditivo de recarga ' + Via_s_(a.NUMERO) + ' de ' + Via_s_(a.SOLICITANTE_NOME) + ', ' + Via_moeda_(a.VALOR_PEDIDO), tg(true), false, false);
      if (semV.length) Adt_gestaoNaHora_(semV, a, r, eu, 'ADT:PAR:' + Via_s_(a.ID), 'G' + Via_s_(a.ENVIADO_EM), 'Para acompanhar · aditivo de recarga ' + Via_s_(a.NUMERO) + ' de ' + Via_s_(a.SOLICITANTE_NOME), tg(false), false, false);
    }
  } catch (e) { console.error('Aditivo de recarga, aviso de envio: ' + Via_erro_(e)); }
}
/**
 * Fila dos avisos da gestão (GS12) para quem é da gestão; quem não é recebe pelo notificador comum (sistema e e-mail). naTela: alerta na
 * tela (Minhas atividades) para os sócios. qualquerHora: sai na hora também fora do expediente.
 */
function Adt_gestaoNaHora_(ids, a, r, eu, refId, marco, titulo, texto, qualquerHora, naTela) {
  var lista = (ids || []).filter(function (x, i, l) { return x && l.indexOf(x) === i; }), res = { ids: [] };
  if (!lista.length) return res;
  if (typeof SGO_avisoGestaoAprovacaoNaHora_ === 'function') {
    res = SGO_avisoGestaoAprovacaoNaHora_({ evento: ADT_EVENTO_GESTAO, modulo: VIA_MODULO, area: '', quem: { id: Via_s_(a.SOLICITANTE_ID), nome: Via_s_(a.SOLICITANTE_NOME) }, destinos: lista,
      qualquerHora: !!qualquerHora, refId: refId, marco: refId + '|' + marco, titulo: titulo, texto: texto, tela: { tipo: 'viagem', id: Via_s_(r.ID) }, resolvePor: '' }) || { ids: [] };
  }
  var naFila = res.ids || [], fora = lista.filter(function (id) { return naFila.indexOf(id) < 0; });
  if (fora.length) Via_notificar_(fora, r, titulo, texto, eu && eu.id === Via_s_(a.SOLICITANTE_ID) ? eu.id : '');
  if (naTela && typeof Atividades_avisar_ === 'function') {
    try { if (typeof Atividades_garantirAbas_ === 'function') Atividades_garantirAbas_(); } catch (e0) {}
    lista.forEach(function (id) { try { Atividades_avisar_(id, '', 'DIRETORIA', titulo, texto, {}); } catch (e1) {} });
  }
  return { gestao: naFila, comuns: fora };
}
/** Avisa os sócios de algo novo no aditivo (complemento, resposta). */
function Adt_avisarSocios_(a, r, eu, oQue, marco) {
  try {
    var urg = Via_up_(a.URGENCIA) === 'PARADO';
    Adt_gestaoNaHora_(Adt_socios_(a, r), a, r, eu, 'ADT:DEC:' + Via_s_(a.ID), marco, (urg ? 'URGENTE · ' : '') + 'Aditivo de recarga ' + Via_s_(a.NUMERO) + ': ' + oQue.slice(0, 80), oQue + '\n' + Adt_resumo_(a, r, true), urg, false);
  } catch (e) { console.error('Aditivo de recarga, aviso aos sócios: ' + Via_erro_(e)); }
}
/** Aviso a quem pediu e ao portador (VG01): sistema, e-mail e WhatsApp; parado aguardando = na hora, a qualquer horário. */
function Adt_avisarPedinte_(a, r, titulo, texto, marco) {
  try {
    var ids = [Via_s_(a.SOLICITANTE_ID), Via_s_(a.PORTADOR_ID)].filter(function (x, i, l) { return x && l.indexOf(x) === i; });
    if (typeof SGO_notificar_ !== 'function') return;
    var parado = Via_up_(a.URGENCIA) === 'PARADO';
    SGO_notificar_({ usuarios: ids, canais: ['sgo', 'email', 'whatsapp'], origem: parado ? ADT_ORIGEM_PARADO : 'VIAGEM', evento: ADT_EVENTO_PEDINTE, refId: ('ADT-' + Via_s_(a.ID) + '-' + marco).slice(0, 80),
      titulo: titulo, texto: texto, link: Via_link_() || undefined });
  } catch (e) { console.error('Aditivo de recarga, aviso a quem pediu: ' + Via_erro_(e)); }
}
function Adt_avisarDecisao_(a, r, eu, dec) {
  try {
    var num = Via_s_(a.NUMERO);
    if (dec === 'APROVAR') {
      var menor = Via_cent_(a.VALOR_APROVADO) < Via_cent_(a.VALOR_PEDIDO);
      Adt_avisarPedinte_(a, r, 'Aditivo ' + num + ' aprovado: ' + Via_moeda_(a.VALOR_APROVADO), 'O aditivo ' + num + ' foi aprovado por ' + eu.nome + ': ' + Via_moeda_(a.VALOR_APROVADO) + (menor ? ' (pedido ' + Via_moeda_(a.VALOR_PEDIDO) + '). Fundamentação: ' + Via_s_(a.FUNDAMENTACAO) : '') + '.\nO Financeiro foi avisado para carregar o cartão Caju de ' + Via_s_(a.PORTADOR_NOME) + '. Você recebe outro aviso quando o crédito estiver disponível.', 'APROVADO');
      var fin = Adt_financeiro_(r), urg = Via_up_(a.URGENCIA) === 'PARADO';
      var tf = 'O aditivo ' + num + ' da viagem ' + Via_s_(r.NUMERO) + ' foi aprovado por ' + eu.nome + '. Carregar ' + Via_moeda_(a.VALOR_APROVADO) + ' no cartão Caju de ' + Via_s_(a.PORTADOR_NOME) + (urg ? ' (está parado aguardando)' : '') + '.\n' +
        'O que fazer: em Depósito de viagem > Carga no cartão, abra a viagem ' + Via_s_(r.NUMERO) + ' e faça a carga (pelo Caju ou manual com o comprovante). O teto da carga já inclui o aditivo; a aprovação da viagem não mudou.' +
        (Via_aprovadoresDaRevisao_(r).length ? '' : '');
      var ttl = (urg ? 'URGENTE · ' : '') + 'Carga do aditivo ' + num + ': ' + Via_moeda_(a.VALOR_APROVADO) + ' no cartão de ' + Via_s_(a.PORTADOR_NOME);
      if (urg && typeof SGO_avisoTresNaHora_ === 'function') SGO_avisoTresNaHora_({ evento: ADT_EVENTO_GESTAO, modulo: VIA_MODULO, quem: { id: eu.id, nome: eu.nome }, destinos: fin, refId: 'ADT:CARGA:' + Via_s_(a.ID), marco: 'CARGA', titulo: ttl, texto: tf, tela: { tipo: 'viagem', id: Via_s_(r.ID) }, resolvePor: '' });
      else Via_notificar_(fin, r, ttl, tf, eu.id);
    } else if (dec === 'INFO') {
      Adt_avisarPedinte_(a, r, 'Aditivo ' + num + ': os sócios pedem informação', eu.nome + ' pediu mais informação sobre o aditivo ' + num + ': ' + Via_s_(a.INFO_PEDIDA) + '\nO que fazer: abra o aditivo (app de campo ou Depósito de viagem > Aditivos de recarga), toque em "Responder" e mande o texto ou a foto. O pedido volta para os sócios na hora.', 'INFO' + Via_s_(a.INFO_PEDIDA_EM));
    } else {
      Adt_avisarPedinte_(a, r, 'Aditivo ' + num + ' negado', 'O aditivo ' + num + ' foi negado por ' + eu.nome + '.\nMotivo: ' + Via_s_(a.FUNDAMENTACAO) + '\nSe a situação mudar, fale com quem decidiu antes de pedir de novo.', 'NEGADO');
    }
  } catch (e) { console.error('Aditivo de recarga, aviso da decisão: ' + Via_erro_(e)); }
}

/**
 * Rodada (Ges_rodada_, a cada 15 minutos, a qualquer hora): aditivo aguardando há 30 minutos (política) recebe UM lembrete aos sócios;
 * aos 60 minutos, a tarefa de ligar para os sócios vai à Wanessa (Financeiro) e ao gestor da área (sistema, e-mail e WhatsApp no
 * expediente; pendência na central). Nada é aprovado por tempo. Devolve { lembretes, escalados }.
 */
function Adt_rodada_(quando) {
  var out = { lembretes: 0, escalados: 0 };
  try {
    Adt_memoLimpar_();
    var abertos = Adt_todos_().filter(function (a) { return Via_up_(a.SITUACAO) === 'AGUARDANDO'; });
    if (!abertos.length) return out;
    var pol = Adt_politica_(), agora = Via_agora_(), agoraMin = Adt_min_(agora);
    var noExp = Adt_noExpediente_();
    abertos.forEach(function (a) {
      // pedido que podia esperar, feito fora do expediente: os sócios são avisados na abertura do expediente
      if (!Via_s_(a.AVISO_SOCIOS_EM)) {
        if (!noExp) return;
        var rA = SGO_DATA.getById(VIA_ABAS.SOLICITACOES, Via_s_(a.ORIGEM_ID)); if (!rA) return;
        var aA = Adt_atualizar_(a.ID, { AVISO_SOCIOS_EM: agora });
        Adt_avisarEnvio_(aA, rA, { id: '', nome: 'sistema' });
        out.avisados = (out.avisados || 0) + 1;
        return;
      }
      var ini = Adt_min_(Adt_desde_(a));
      if (ini === null) return;
      var passou = agoraMin - ini, r = SGO_DATA.getById(VIA_ABAS.SOLICITACOES, Via_s_(a.ORIGEM_ID));
      if (!r) return;
      var urg = Via_up_(a.URGENCIA) === 'PARADO', sist = { id: '', nome: 'sistema' };
      if (passou >= pol.lembreteMin && !Via_s_(a.LEMBRETE_EM)) {
        Adt_atualizar_(a.ID, { LEMBRETE_EM: agora });
        Adt_gestaoNaHora_(Adt_socios_(a, r), a, r, sist, 'ADT:DEC:' + Via_s_(a.ID), 'L', (urg ? 'URGENTE · ' : '') + 'Lembrete: aditivo ' + Via_s_(a.NUMERO) + ' aguarda há ' + Math.round(passou) + ' min (' + Via_s_(a.SOLICITANTE_NOME) + ', ' + Via_moeda_(a.VALOR_PEDIDO) + ')',
          'Lembrete único: o aditivo ' + Via_s_(a.NUMERO) + ' aguarda a decisão de um dos sócios há ' + Math.round(passou) + ' minutos.' + (urg ? ' Quem pediu está parado aguardando.' : '') + '\n' + Adt_resumo_(a, r, true), urg, false);
        Adt_historico_(a, 'LEMBRETE', sist, 'Lembrete aos sócios: aguarda há ' + Math.round(passou) + ' minutos.');
        out.lembretes++;
      }
      if (passou >= pol.escalarMin && !Via_s_(a.ESCALADO_EM)) {
        Adt_atualizar_(a.ID, { ESCALADO_EM: agora });
        var ids = Adt_financeiro_(r).concat(Adt_gestores_(a, r)).filter(function (x, i, l) { return l.indexOf(x) === i; });
        var t = 'Tarefa: ligar para os sócios. O aditivo ' + Via_s_(a.NUMERO) + ' de ' + Via_s_(a.SOLICITANTE_NOME) + ' (viagem ' + Via_s_(r.NUMERO) + ', ' + Adt_nomeCat_(a.CATEGORIA).toLowerCase() + ') está parado há ' + Math.round(passou) + ' minutos sem decisão' + (urg ? ' e a pessoa está parada aguardando' : '') + '.\nO que fazer: ligue para ' + Via_nomes_(Adt_socios_(a, r)).join(' ou ') + ' e peça a decisão no SGO+ (Depósito de viagem > Aditivos de recarga). Nada é aprovado por tempo.';
        Adt_gestaoNaHora_(ids, a, r, sist, 'ADT:LIGAR:' + Via_s_(a.ID), 'E', 'Ligar para os sócios: aditivo ' + Via_s_(a.NUMERO) + ' parado há ' + Math.round(passou) + ' min', t, false, false);
        Adt_historico_(a, 'ESCALADO', sist, 'Parado há ' + Math.round(passou) + ' minutos: tarefa de ligar para os sócios enviada a ' + Via_nomes_(ids).join(', ') + '.');
        out.escalados++;
      }
    });
  } catch (e) { out.erro = Via_erro_(e); console.error('Aditivo de recarga (rodada): ' + out.erro); }
  return out;
}

// ------------------------------------------------------------
// CENTRAL DE PENDÊNCIAS E CAIXA DE DECISÕES
// ------------------------------------------------------------
var ADT_PEND_TIPOS = {
  aditivo_decidir: { modulo: 'viagem', um: 'aditivo de recarga em viagem aguardando a sua decisão', varios: 'aditivos de recarga em viagem aguardando a sua decisão', rotulo: 'Decidir o aditivo', fazer: 'decida em Depósito de viagem > Aditivos de recarga (basta um sócio)', tela: { tipo: 'viagem' }, origem: 'VIAGEM' },
  aditivo_ligar: { modulo: 'viagem', um: 'aditivo parado: ligar para os sócios', varios: 'aditivos parados: ligar para os sócios', rotulo: 'Ligar para os sócios', fazer: 'ligue para os sócios e peça a decisão do aditivo', tela: { tipo: 'viagem' }, origem: 'VIAGEM' },
  aditivo_info: { modulo: 'viagem', um: 'aditivo de recarga com pedido de informação para você', varios: 'aditivos com pedido de informação para você', rotulo: 'Responder', fazer: 'responda no aditivo (texto ou foto)', tela: { tipo: 'viagem' }, origem: 'VIAGEM' },
  aditivo_excecao: { modulo: 'viagem', um: 'carga de aditivo feita como exceção para conferir', varios: 'cargas de aditivo feitas como exceção para conferir', rotulo: 'Conferir a carga', fazer: 'confira o comprovante e o valor e marque como conferida', tela: { tipo: 'viagem' }, origem: 'VIAGEM' },
  aditivo_repassar: { modulo: 'viagem', um: 'gasto de viagem a repassar ao cliente', varios: 'gastos de viagem a repassar ao cliente', rotulo: 'Tratar o repasse', fazer: 'inclua no faturamento ou no orçamento do chamado e registre no aditivo', tela: { tipo: 'viagem' }, origem: 'VIAGEM' }
};
function Adt_registrarTipos_() {
  try {
    if (typeof PEND_TIPOS !== 'undefined' && PEND_TIPOS) Object.keys(ADT_PEND_TIPOS).forEach(function (k) { if (!PEND_TIPOS[k]) PEND_TIPOS[k] = ADT_PEND_TIPOS[k]; });
    if (typeof GES_TIPOS !== 'undefined' && GES_TIPOS && !GES_TIPOS.aditivo_decidir) GES_TIPOS.aditivo_decidir = { prazo: 1 };
  } catch (e) { try { console.error('Aditivo de recarga, registro na central: ' + Via_erro_(e)); } catch (x) {} }
}
/** Itens da central (sem valores no título). */
function Adt_fontePendencias_(add) {
  if (typeof Pend_item_ !== 'function') return;
  Adt_registrarTipos_();
  if (typeof PEND_TIPOS === 'undefined' || !PEND_TIPOS.aditivo_decidir) return;
  if (typeof Pend_abaExiste_ === 'function' && !Pend_abaExiste_(ADT_ABA)) return;
  var cache = {}, sol = function (id) { if (!(id in cache)) cache[id] = SGO_DATA.getById(VIA_ABAS.SOLICITACOES, id) || null; return cache[id]; };
  Adt_todos_().forEach(function (a) {
    var s = Via_up_(a.SITUACAO), r = sol(Via_s_(a.ORIGEM_ID)), num = Via_s_(a.NUMERO);
    if (!r) return;
    var tela = { tipo: 'viagem', id: Via_s_(r.ID) }, urg = Via_up_(a.URGENCIA) === 'PARADO';
    if (s === 'AGUARDANDO') {
      var socios = Adt_socios_(a, r);
      add(Pend_item_('aditivo_decidir', { id: 'ADT:DEC:' + Via_s_(a.ID), nome: num, publico: 'PESSOA', paraUsuarios: socios, responsavel: Via_s_(a.SOLICITANTE_NOME), responsavelId: Via_s_(a.SOLICITANTE_ID),
        gravidade: urg ? 'CRITICO' : 'ATENCAO', dias: null, titulo: (urg ? 'Urgente (parado aguardando): ' : '') + 'decidir o aditivo de recarga ' + num + ' (' + Adt_nomeCat_(a.CATEGORIA).toLowerCase() + ')',
        detalhe: 'Pedido de ' + Via_s_(a.SOLICITANTE_NOME) + ' em ' + Via_br_(a.ENVIADO_EM) + ', viagem ' + Via_s_(r.NUMERO) + ' (' + Via_s_(r.DESTINO_CIDADE) + '/' + Via_up_(r.DESTINO_UF) + ').',
        oQueFazer: 'Abra Depósito de viagem > Aditivos de recarga e aprove, aprove com valor menor, peça informação ou negue. Basta um sócio.', tela: tela,
        extra: { soDiretoria: true, naoPode: Adt_conflito_(a, r) } }));
      if (Via_s_(a.ESCALADO_EM)) {
        var lig = Adt_financeiro_(r).concat(Adt_gestores_(a, r)).filter(function (x, i, l) { return l.indexOf(x) === i; });
        if (lig.length) add(Pend_item_('aditivo_ligar', { id: 'ADT:LIGAR:' + Via_s_(a.ID), nome: num, publico: 'PESSOA', paraUsuarios: lig, responsavel: Via_s_(a.SOLICITANTE_NOME), responsavelId: Via_s_(a.SOLICITANTE_ID),
          gravidade: 'CRITICO', dias: null, titulo: 'Ligar para os sócios: aditivo ' + num + ' parado desde ' + Adt_hora_(a.ENVIADO_EM), detalhe: 'Pedido de ' + Via_s_(a.SOLICITANTE_NOME) + (urg ? ', parado aguardando' : '') + '.',
          oQueFazer: 'Ligue para ' + Via_nomes_(Adt_socios_(a, r)).join(' ou ') + ' e peça a decisão no SGO+.', tela: tela }));
      }
    }
    if (s === 'INFORMACAO') add(Pend_item_('aditivo_info', { id: 'ADT:INFO:' + Via_s_(a.ID) + ':' + Via_s_(a.INFO_PEDIDA_EM), nome: num, publico: 'PESSOA', paraUsuarios: [Via_s_(a.SOLICITANTE_ID)], responsavel: Via_s_(a.SOLICITANTE_NOME),
      responsavelId: Via_s_(a.SOLICITANTE_ID), gravidade: 'CRITICO', dias: null, titulo: 'Responder aos sócios: aditivo ' + num, detalhe: Via_s_(a.INFO_PEDIDA_POR_NOME) + ' pediu: ' + Via_s_(a.INFO_PEDIDA),
      oQueFazer: 'Abra o aditivo e toque em "Responder" (texto ou foto).', tela: tela }));
    if (Via_up_(a.MESMA_PESSOA) === 'SIM' && !Via_s_(a.EXCECAO_CONFERIDA_EM)) {
      var conf = Via_comPapel_('VIAGEM_CONFERIR', Via_conflito_(r).concat([Via_s_(a.DECIDIDO_POR_ID)]));
      if (conf.length) add(Pend_item_('aditivo_excecao', { id: 'ADT:EXC:' + Via_s_(a.ID), nome: num, publico: 'PESSOA', paraUsuarios: conf, responsavel: Via_s_(a.EXCECAO_POR_NOME), responsavelId: Via_s_(a.DECIDIDO_POR_ID),
        gravidade: 'ATENCAO', dias: null, titulo: 'Conferir a carga de exceção do aditivo ' + num, detalhe: 'Carga registrada por quem aprovou (' + Via_s_(a.EXCECAO_POR_NOME) + '). Motivo: ' + Via_s_(a.EXCECAO_MOTIVO),
        oQueFazer: 'Abra a viagem ' + Via_s_(r.NUMERO) + ', confira o comprovante e o valor e marque a carga como conferida no aditivo.', tela: tela }));
    }
    if (Via_up_(a.REPASSAR_CLIENTE) === 'SIM' && Adt_aprovadoValor_(a) > 0 && !Via_s_(a.REPASSE_TRATADO_EM)) {
      var rp = Adt_repassadores_(a, r);
      if (rp.length) add(Pend_item_('aditivo_repassar', { id: 'ADT:REP:' + Via_s_(a.ID), nome: num, publico: 'PESSOA', paraUsuarios: rp, responsavel: Via_s_(a.SOLICITANTE_NOME), responsavelId: Via_s_(a.SOLICITANTE_ID),
        gravidade: 'ATENCAO', dias: null, titulo: 'Repassar ao cliente o gasto do aditivo ' + num + (Via_s_(r.CLIENTE_NOME) ? ' (' + Via_s_(r.CLIENTE_NOME) + ')' : ''),
        detalhe: Adt_nomeCat_(a.CATEGORIA) + ' na viagem ' + Via_s_(r.NUMERO) + (Via_s_(a.VINCULO_REF) ? ', ' + Via_s_(a.VINCULO_REF) : '') + '. O valor está na viagem (Financeiro).',
        oQueFazer: 'Inclua no faturamento ou no orçamento do chamado e registre no aditivo como foi tratado.', tela: tela }));
    }
  });
}

// ------------------------------------------------------------
// PARA A TELA
// ------------------------------------------------------------
function Adt_paraTela_(eu, a, r, al) {
  r = r || SGO_DATA.getById(VIA_ABAS.SOLICITACOES, Via_s_(a.ORIGEM_ID)) || {};
  var s = Via_up_(a.SITUACAO), ve = Adt_veValor_(eu, a, r), pol = Adt_politica_(), socio = Adt_ehSocio_(eu), conflito = Adt_conflito_(a, r).indexOf(eu.id) >= 0;
  var pedinte = Via_s_(a.SOLICITANTE_ID) === eu.id || Via_s_(r.SOLICITANTE_ID) === eu.id, aberto = ADT_ABERTOS.indexOf(s) >= 0;
  var socios = r.ID ? Via_nomes_(Adt_socios_(a, r)) : [];
  al = al || (r.ID ? Adt_alocacao_(r) : {});
  var x = al[Via_s_(a.ID)] || { carregado: Number(a.CARREGADO_TOTAL) || 0, falta: 0 };
  var nao = function (m) { return { pode: false, motivo: m }; }, sim = { pode: true, motivo: '' };
  var ac = {
    cancelar: pedinte && (aberto || (s === 'APROVADO' && !(x.carregado > 0))) ? sim : nao('Só quem pediu cancela, antes da carga.'),
    complementar: pedinte && aberto ? sim : nao('Só quem pediu complementa, antes da decisão.'),
    decidir: !aberto ? nao('Já decidido.') : !socio ? nao('A decisão é de um dos sócios (' + socios.join(' ou ') + ').') : conflito ? nao('Você está nesta viagem ou pediu o aditivo: o outro sócio decide.') : sim,
    parecer: aberto && r.ID && Adt_gestores_(a, r).indexOf(eu.id) >= 0 ? sim : nao('O parecer é do gestor da área de quem pediu.'),
    carga: r.ID ? Adt_acoesCarga_(eu, a, r) : nao(''),
    conferirExcecao: Via_up_(a.MESMA_PESSOA) === 'SIM' && !Via_s_(a.EXCECAO_CONFERIDA_EM) && (Via_pode_(eu, 'VIAGEM_CONFERIR') || Via_pode_(eu, 'VIAGEM_DEPOSITAR')) && Via_s_(a.DECIDIDO_POR_ID) !== eu.id ? sim : nao(''),
    repasse: Via_up_(a.REPASSAR_CLIENTE) === 'SIM' && Adt_aprovadoValor_(a) > 0 && !Via_s_(a.REPASSE_TRATADO_EM) && r.ID && (Adt_repassadores_(a, r).indexOf(eu.id) >= 0 || socio) ? sim : nao('')
  };
  var andamento = '';
  if (s === 'AGUARDANDO' && !Via_s_(a.AVISO_SOCIOS_EM)) andamento = 'Aditivo ' + Via_s_(a.NUMERO) + ' enviado às ' + Adt_hora_(a.ENVIADO_EM) + ' de ' + Via_brDia_(a.ENVIADO_EM) + '. Como pode ser decidido hoje, ' + (socios.join(' e ') || 'os sócios') + ' recebem o aviso na abertura do expediente.';
  else if (s === 'AGUARDANDO') andamento = 'Aditivo ' + Via_s_(a.NUMERO) + ' enviado às ' + Adt_hora_(a.ENVIADO_EM) + ' de ' + Via_brDia_(a.ENVIADO_EM) + '. ' + (socios.length ? socios.join(' e ') + (socios.length === 1 ? ' foi avisado' : ' foram avisados') + ' por WhatsApp e e-mail' + (Adt_desde_(a) !== Via_s_(a.ENVIADO_EM) ? ' às ' + Adt_hora_(Adt_desde_(a)) : '') + '. ' : '') +
    (Via_s_(a.LEMBRETE_EM) ? 'Lembrete enviado às ' + Adt_hora_(a.LEMBRETE_EM) + '. ' : 'Lembrete automático às ' + Adt_hora_(Adt_somarMin_(Adt_desde_(a), pol.lembreteMin)) + '. ') +
    (Via_s_(a.ESCALADO_EM) ? 'Às ' + Adt_hora_(a.ESCALADO_EM) + ', o Financeiro e o gestor receberam a tarefa de ligar para os sócios.' : 'Se não houver decisão até ' + Adt_hora_(Adt_somarMin_(Adt_desde_(a), pol.escalarMin)) + ', o Financeiro e o gestor ligam para os sócios.');
  else if (s === 'INFORMACAO') andamento = Via_s_(a.INFO_PEDIDA_POR_NOME) + ' pediu informação às ' + Adt_hora_(a.INFO_PEDIDA_EM) + ': ' + Via_s_(a.INFO_PEDIDA) + ' Responda com texto ou foto; o pedido volta aos sócios na hora.';
  else if (s === 'APROVADO') andamento = 'Aprovado por ' + Via_s_(a.DECIDIDO_POR_NOME) + ' às ' + Adt_hora_(a.DECIDIDO_EM) + '. Aguardando a carga no cartão de ' + Via_s_(a.PORTADOR_NOME) + (x.carregado > 0 && ve ? ' (já carregado ' + Via_moeda_(x.carregado) + ')' : '') + '.';
  else if (s === 'CARREGADO') andamento = 'Carregado no cartão de ' + Via_s_(a.PORTADOR_NOME) + ' em ' + Via_br_(a.CARREGADO_EM) + '. Na prestação de contas, marque os gastos com este aditivo.';
  else if (s === 'NEGADO') andamento = 'Negado por ' + Via_s_(a.DECIDIDO_POR_NOME) + ' às ' + Adt_hora_(a.DECIDIDO_EM) + '. Motivo: ' + Via_s_(a.FUNDAMENTACAO);
  else if (s === 'CANCELADO') andamento = 'Cancelado por ' + Via_s_(a.CANCELADO_POR_NOME) + ' em ' + Via_br_(a.CANCELADO_EM) + '. Motivo: ' + Via_s_(a.CANCELADO_MOTIVO);
  var tv = r.ID && socio && aberto && typeof Via_vencidasDe_ === 'function' ? Via_vencidasDe_(Via_s_(r.RESPONSAVEL_ID), Via_s_(r.ID)) : [];
  return { id: Via_s_(a.ID), numero: Via_s_(a.NUMERO), seq: Number(a.SEQ) || 0, situacao: s, situacaoNome: ADT_SITUACOES[s] || s, aberto: aberto, categoria: Via_up_(a.CATEGORIA), categoriaNome: Adt_nomeCat_(a.CATEGORIA),
    veValor: ve, valorTxt: ve ? Via_moeda_(a.VALOR_PEDIDO) : '', valorPedido: ve ? Number(a.VALOR_PEDIDO) || 0 : null, valorAprovadoTxt: ve && Via_s_(a.VALOR_APROVADO) !== '' ? Via_moeda_(a.VALOR_APROVADO) : '',
    carregadoTxt: ve && x.carregado > 0 ? Via_moeda_(x.carregado) : '', faltaTxt: ve && x.falta > 0 ? Via_moeda_(x.falta) : '', falta: ve ? x.falta : null,
    justificativa: Via_s_(a.JUSTIFICATIVA), urgencia: Via_up_(a.URGENCIA), urgente: Via_up_(a.URGENCIA) === 'PARADO', urgenciaNome: ADT_URGENCIAS[Via_up_(a.URGENCIA)] || '',
    repassar: Via_up_(a.REPASSAR_CLIENTE) || 'A_DEFINIR', repassarNome: ADT_REPASSAR[Via_up_(a.REPASSAR_CLIENTE)] || 'A definir', vinculoRef: Via_s_(a.VINCULO_REF),
    solicitante: Via_s_(a.SOLICITANTE_NOME), portador: Via_s_(a.PORTADOR_NOME), meu: pedinte,
    viagem: { id: Via_s_(r.ID || a.ORIGEM_ID), numero: Via_s_(a.ORIGEM_NUMERO), destino: [Via_s_(r.DESTINO_CIDADE), Via_up_(r.DESTINO_UF)].filter(Boolean).join('/'), cliente: Via_s_(r.CLIENTE_NOME) },
    enviadoEm: Via_br_(a.ENVIADO_EM), decididoPor: Via_s_(a.DECIDIDO_POR_NOME), decididoEm: Via_br_(a.DECIDIDO_EM), fundamentacao: Via_s_(a.FUNDAMENTACAO),
    info: Via_s_(a.INFO_PEDIDA) ? { texto: Via_s_(a.INFO_PEDIDA), por: Via_s_(a.INFO_PEDIDA_POR_NOME), em: Via_br_(a.INFO_PEDIDA_EM) } : null,
    parecer: Via_s_(a.PARECER_GESTOR) ? { nome: ADT_PARECERES[Via_up_(a.PARECER_GESTOR)] || '', texto: Via_s_(a.PARECER_TEXTO), por: Via_s_(a.PARECER_POR_NOME), em: Via_br_(a.PARECER_EM) } : null,
    complementos: Via_json_(a.COMPLEMENTOS_JSON, []), anexos: Via_json_(a.ANEXOS_JSON, []).map(function (f) { return { nome: f.nome, url: f.url, por: f.por || '', em: Via_br_(f.em) }; }),
    excecao: Via_up_(a.MESMA_PESSOA) === 'SIM' ? { por: Via_s_(a.EXCECAO_POR_NOME), motivo: Via_s_(a.EXCECAO_MOTIVO), conferidaEm: Via_br_(a.EXCECAO_CONFERIDA_EM), conferidaPor: Via_s_(a.EXCECAO_CONFERIDA_POR_NOME), texto: Via_s_(a.EXCECAO_CONFERIDA_TEXTO) } : null,
    repasse: Via_s_(a.REPASSE_TRATADO_EM) ? { em: Via_br_(a.REPASSE_TRATADO_EM), por: Via_s_(a.REPASSE_TRATADO_POR_NOME), texto: Via_s_(a.REPASSE_TEXTO) } : null,
    apontamentos: tv.length ? [Via_s_(r.RESPONSAVEL_NOME) + ' tem prestação de contas vencida (' + tv.map(function (y) { return Via_s_(y.r.NUMERO) + ' desde ' + y.pz.prazoTxt; }).join('; ') + '). Aprovar registra também a liberação da trava para esta viagem (2 dias).'] : [],
    andamento: andamento, acoes: ac };
}
/** Aditivos da viagem para a tela da solicitação (e para a prestação). */
function Adt_daViagemTela_(eu, r) {
  var al = Adt_alocacao_(r);
  return Adt_daViagem_(r.ID).map(function (a) { return Adt_paraTela_(eu, a, r, al); });
}
function Adt_contexto_(eu) {
  Adt_memoLimpar_();
  var todas = Via_ler_(VIA_ABAS.SOLICITACOES), viagens = [], indisp = [], hoje = Via_hoje_();
  todas.forEach(function (r) {
    if (Via_s_(r.SOLICITANTE_ID) !== eu.id && Via_equipeIds_(r).indexOf(eu.id) < 0) return;
    var m = Adt_motivoViagem_(eu, r);
    var item = { id: Via_s_(r.ID), numero: Via_s_(r.NUMERO), destino: Via_s_(r.DESTINO_CIDADE) + '/' + Via_up_(r.DESTINO_UF), saida: Via_brDia_(r.SAIDA_EM), chegada: Via_brDia_(r.CHEGADA_EM),
      responsavel: Via_s_(r.RESPONSAVEL_NOME), cliente: Via_s_(r.CLIENTE_NOME), vinculoRef: Via_s_(r.VINCULO_REF) };
    if (!m) viagens.push(item);
    else if (['NEGADA', 'CANCELADA', 'ENCERRADA', 'RASCUNHO'].indexOf(Via_up_(r.SITUACAO)) < 0 && Via_dia_(r.CHEGADA_EM) >= Via_somarDias_(hoje, -15)) indisp.push(Object.assign(item, { motivo: m }));
  });
  var cacheR = {}, sol = function (id) { if (!(id in cacheR)) cacheR[id] = todas.filter(function (x) { return Via_s_(x.ID) === id; })[0] || null; return cacheR[id]; };
  var tela = [];
  Adt_todos_().forEach(function (a) {
    var r = sol(Via_s_(a.ORIGEM_ID)); if (!r) return;
    var t = Adt_paraTela_(eu, a, r), ac = t.acoes, s = t.situacao;
    var grupos = [];
    if (t.meu || Via_s_(a.PORTADOR_ID) === eu.id) grupos.push('meus');
    if (ac.decidir.pode) grupos.push('decidir');
    if (ac.parecer.pode) grupos.push('parecer');
    if (ac.carga.pode) grupos.push('carga');
    if (ac.conferirExcecao.pode) grupos.push('conferir');
    if (ac.repasse.pode) grupos.push('repasse');
    if (!grupos.length && Adt_ehSocio_(eu) && (ADT_ABERTOS.indexOf(s) >= 0 || s === 'APROVADO')) grupos.push('acompanhar');
    if (grupos.length) { t.grupos = grupos; tela.push(t); }
  });
  tela.sort(function (x, y) { return (y.aberto - x.aberto) || (y.urgente - x.urgente) || y.enviadoEm.localeCompare(x.enviadoEm); });
  var pol = Adt_politica_();
  return { viagens: viagens, indisponiveis: indisp, aditivos: tela, categorias: ADT_CATEGORIAS, urgencias: ADT_URGENCIAS, repassar: ADT_REPASSAR, pareceres: ADT_PARECERES,
    minimos: { justificativa: ADT_JUSTIFICATIVA_MIN, motivo: ADT_MOTIVO_MIN }, exemplo: ADT_EXEMPLO, politica: { lembreteMin: pol.lembreteMin, escalarMin: pol.escalarMin, fotoAcimaDe: pol.fotoAcimaDe, fotoAcimaDeTxt: pol.fotoAcimaDe ? Via_moeda_(pol.fotoAcimaDe) : '' },
    semViagemTexto: 'Você não tem viagem nem recarga em andamento. Para um gasto da rotina, use Minha recarga Caju > Pedir recarga; para uma viagem, peça ao seu gestor a solicitação de depósito.',
    socio: Adt_ehSocio_(eu), contagem: Adt_contagemDe_(tela) };
}
function Adt_contagemDe_(tela) {
  return tela.filter(function (t) { return (t.grupos || []).some(function (g) { return ['decidir', 'parecer', 'carga', 'conferir', 'repasse'].indexOf(g) >= 0; }) || (t.meu && t.situacao === 'INFORMACAO'); }).length;
}
/** Para Viagem_api 'iniciar' (o número no menu e no "para você agora"). Nunca lança. */
function Adt_contagem_(eu) { try { return Adt_contagemDe_(Adt_contexto_(eu).aditivos); } catch (e) { return 0; } }

// ------------------------------------------------------------
// PRESTAÇÃO DE CONTAS, FECHAMENTO E RELATÓRIOS
// ------------------------------------------------------------
/** Confere o aditivo escolhido num gasto da prestação. Devolve o ID ('' = orçado na viagem). */
function Adt_validarGasto_(r, aditivoId) {
  if (!Via_s_(aditivoId)) return '';
  var a = Adt_daViagem_(r.ID).filter(function (x) { return Via_s_(x.ID) === Via_s_(aditivoId); })[0];
  if (!a) throw new Error('Não foi possível lançar o gasto: o aditivo escolhido não é desta viagem. Escolha de novo ou deixe "orçado na viagem".');
  if (Adt_aprovadoValor_(a) <= 0) throw new Error('Não foi possível lançar o gasto no aditivo ' + Via_s_(a.NUMERO) + ': ele não foi aprovado (' + (ADT_SITUACOES[Via_up_(a.SITUACAO)] || a.SITUACAO).toLowerCase() + '). Lance como gasto da viagem; se foi pago com dinheiro próprio, vira reembolso.');
  return Via_s_(a.ID);
}
function Adt_numeroDe_(id) { var a = Adt_todos_().filter(function (x) { return Via_s_(x.ID) === Via_s_(id); })[0]; return a ? Via_s_(a.NUMERO) : ''; }
/** Enviar a prestação com aditivo aguardando decisão: recusa com o caminho (null = pode). */
function Adt_bloqueioPrestacao_(r) {
  var ab = Adt_daViagem_(r.ID).filter(function (a) { return ADT_ABERTOS.indexOf(Via_up_(a.SITUACAO)) >= 0; });
  if (!ab.length) return null;
  return 'há aditivo de recarga aguardando decisão (' + ab.map(function (a) { return Via_s_(a.NUMERO); }).join(', ') + '). Espere a decisão dos sócios ou cancele o aditivo (Depósito de viagem > Aditivos de recarga) e envie de novo.';
}
/** Para o seletor do gasto e o quadro "previsto × realizado" da prestação. */
function Adt_paraPrestacao_(r, itens) {
  itens = itens || (typeof Via_itensAtivos_ === 'function' ? Via_itensAtivos_(r.ID) : []);
  var al = Adt_alocacao_(r);
  return Adt_daViagem_(r.ID).filter(function (a) { return Adt_aprovadoValor_(a) > 0; }).map(function (a) {
    var g = 0, ac = 0, gl = 0, n = 0, conferida = typeof Via_conferida_ === 'function' && Via_conferida_(r);
    itens.forEach(function (i) {
      if (Via_s_(i.ADITIVO_ID) !== Via_s_(a.ID)) return;
      var v = Via_cent_(i.VALOR), sit = Via_up_(i.SITUACAO), glo = sit === 'GLOSADO' ? Math.min(v, Via_cent_(i.VALOR_GLOSADO)) : 0;
      g += v; gl += glo; ac += sit === 'ACEITO' ? v : sit === 'GLOSADO' ? v - glo : 0; n++;
    });
    var x = al[Via_s_(a.ID)] || { carregado: 0 };
    return { id: Via_s_(a.ID), numero: Via_s_(a.NUMERO), seq: Number(a.SEQ) || 0, rotulo: 'A' + (Number(a.SEQ) || 0) + ' · ' + Adt_nomeCat_(a.CATEGORIA), categoriaNome: Adt_nomeCat_(a.CATEGORIA),
      aprovado: Adt_aprovadoValor_(a), aprovadoTxt: Via_moeda_(Adt_aprovadoValor_(a)), carregado: x.carregado, carregadoTxt: Via_moeda_(x.carregado), gasto: g / 100, gastoTxt: Via_moeda_(g / 100),
      aceito: ac / 100, aceitoTxt: conferida ? Via_moeda_(ac / 100) : '', glosado: gl / 100, glosadoTxt: Via_moeda_(gl / 100), itens: n };
  });
}
/** Seção do A4 de fechamento: previsto (orçado + aditivos) × realizado. num: formatador do A4. Devolve '' sem aditivo aprovado. */
function Adt_previstoRealizadoHtml_(r, k, num) {
  var ads = Adt_paraPrestacao_(r);
  if (!ads.length) return '';
  var semAd = function (cod) { return Via_itensAtivos_(r.ID).filter(function (i) { return !Via_s_(i.ADITIVO_ID) && Via_up_(i.CATEGORIA) === cod; }); };
  var linhas = k.porCategoria.map(function (x) {
    var it = semAd(x.cod), g = it.reduce(function (s, i) { return s + Via_cent_(i.VALOR); }, 0) / 100;
    return [x.nome, num(x.orcado), '—', num(x.aprovado), '—', num(g), k.conferida ? num(x.aceito) : '—', num(x.glosado)];
  });
  ads.forEach(function (a) { linhas.push(['Aditivo ' + a.rotulo, '—', num(a.aprovado), num(a.aprovado), num(a.carregado), num(a.gasto), k.conferida ? num(a.aceito) : '—', num(a.glosado)]); });
  var totAd = ads.reduce(function (s, a) { return s + Via_cent_(a.aprovado); }, 0) / 100, totOrc = k.porCategoria.reduce(function (s, x) { return s + Via_cent_(x.orcado); }, 0) / 100, totApr = Number(r.APROVADO_TOTAL) || 0;
  return '<h2>2b. Previsto × realizado, com os aditivos de recarga</h2>' +
    '<p>O previsto é o aprovado na solicitação mais os aditivos aprovados durante a viagem (cada aditivo foi decidido por um sócio, sem mudar a aprovação da viagem). Os gastos marcados com um aditivo aparecem na linha dele; os demais, na categoria. A carga do cartão é do cartão inteiro: na linha do aditivo aparece a parte da carga que cobriu o aditivo.</p>' +
    SGO_DocA4_tabela_([{ t: 'Linha' }, { t: 'Orçado', cls: 'num' }, { t: 'Aditivos aprovados', cls: 'num' }, { t: 'Previsto total', cls: 'num' }, { t: 'Carregado', cls: 'num' }, { t: 'Gasto', cls: 'num' }, { t: 'Aceito', cls: 'num' }, { t: 'Glosado', cls: 'num' }], linhas,
      { rodape: [{ html: '<b>Total</b>' }, num(totOrc), num(totAd), num(Via_r2_(totApr + totAd)), num(k.carregado), num(k.gasto), k.conferida ? num(k.aceito) : '—', num(k.glosado)] });
}
/** Compras > Relatórios > "Peças compradas em viagem" (só leitura): gastos da prestação ligados a aditivo de peça, usinagem ou ferramenta. */
function Adt_pecasEmViagem_(de, ate) {
  var ads = {};
  Adt_todos_().forEach(function (a) { if (ADT_CATS_PECA.indexOf(Via_up_(a.CATEGORIA)) >= 0) ads[Via_s_(a.ID)] = a; });
  return Via_ler_(VIA_ABAS.PRESTACOES).filter(function (i) { var d = Via_dia_(i.DATA); return !Via_s_(i.REMOVIDO_EM) && ads[Via_s_(i.ADITIVO_ID)] && (!de || d >= de) && (!ate || d <= ate); })
    .sort(function (a, b) { return Via_dia_(a.DATA).localeCompare(Via_dia_(b.DATA)); })
    .map(function (i) { var a = ads[Via_s_(i.ADITIVO_ID)]; return { data: Via_brDia_(i.DATA), viagem: Via_s_(i.NUMERO), aditivo: Via_s_(a.NUMERO).replace(/^.*\//, '') + ' · ' + Adt_nomeCat_(a.CATEGORIA), estabelecimento: Via_s_(i.ESTABELECIMENTO),
      cnpj: Via_s_(i.CNPJ), descricao: Via_s_(i.DESCRICAO), cliente: Via_s_(a.CLIENTE_NOME), pessoa: Via_s_(i.PESSOA_NOME), valor: Number(i.VALOR) || 0, valorTxt: Via_moeda_(i.VALOR) }; });
}
/** Relatório A4 "Aditivos de recarga" (Depósito de viagem > Relatórios A4). l: as viagens que a pessoa vê no período. */
function Adt_relatorioCorpo_(eu, l, de, ate) {
  var ids = {}; l.forEach(function (x) { ids[x.id] = x; });
  var lista = Adt_todos_().filter(function (a) { var d = Via_dia_(a.ENVIADO_EM); return ids[Via_s_(a.ORIGEM_ID)] && (!de || d >= de) && (!ate || d <= ate); });
  var m = Via_moeda_, soma = function (arr, f) { return Via_r2_(arr.reduce(function (s, a) { return s + (Number(f(a)) || 0); }, 0)); };
  var aprov = lista.filter(function (a) { return Adt_aprovadoValor_(a) > 0; }), neg = lista.filter(function (a) { return Via_up_(a.SITUACAO) === 'NEGADO'; });
  var tempos = lista.filter(function (a) { return Via_s_(a.DECIDIDO_EM) && Via_s_(a.ENVIADO_EM); }).map(function (a) { return Math.max(0, Adt_min_(a.DECIDIDO_EM) - Adt_min_(a.ENVIADO_EM)); });
  var med = tempos.length ? tempos.slice().sort(function (a, b) { return a - b; })[Math.floor(tempos.length / 2)] : null;
  var rep = aprov.filter(function (a) { return Via_up_(a.REPASSAR_CLIENTE) === 'SIM'; }), repAb = rep.filter(function (a) { return !Via_s_(a.REPASSE_TRATADO_EM); });
  var grupo = function (f) { var g = {}; lista.forEach(function (a) { var k = f(a) || 'Não informado'; g[k] = g[k] || { nome: k, n: 0, aprovado: 0, negados: 0 }; g[k].n++; g[k].aprovado = Via_r2_(g[k].aprovado + Adt_aprovadoValor_(a)); if (Via_up_(a.SITUACAO) === 'NEGADO') g[k].negados++; }); return Object.keys(g).map(function (k) { return g[k]; }).sort(function (a, b) { return b.aprovado - a.aprovado || a.nome.localeCompare(b.nome, 'pt-BR'); }); };
  var tab = function (g, rot, leg) { return RelA4_tabela_([{ t: rot }, { t: 'Aditivos', num: true }, { t: 'Negados', num: true }, { t: 'Aprovado', num: true }], g.map(function (x) { return [x.nome, String(x.n), String(x.negados), m(x.aprovado)]; }), { legenda: leg, vazio: 'Nenhum aditivo no período.' }); };
  var corpo = RelA4_secao_('Resumo dos aditivos de recarga', RelA4_kpis_([[String(lista.length), 'Aditivos pedidos'], [String(aprov.length) + ' · ' + m(soma(aprov, Adt_aprovadoValor_)), 'Aprovados', 'ok'], [String(neg.length), 'Negados', neg.length ? 'aviso' : ''],
    [med === null ? '—' : Math.round(med) + ' min', 'Tempo até a decisão (mediana)', med !== null && med > 60 ? 'aviso' : ''], [String(lista.filter(function (a) { return Via_s_(a.ESCALADO_EM); }).length), 'Escalados aos 60 minutos', ''],
    [String(repAb.length) + ' · ' + m(soma(repAb, Adt_aprovadoValor_)), 'A repassar ao cliente (não tratados)', repAb.length ? 'aviso' : 'ok'], [String(lista.filter(function (a) { return Via_up_(a.MESMA_PESSOA) === 'SIM'; }).length), 'Cargas de exceção (por quem aprovou)', '']]) +
    RelA4_caixa_('Aditivo de recarga: pedido feito durante a viagem, decidido por um sócio (o dono ou a Diretoria), sem mudar a aprovação da viagem. O aprovado soma ao teto de carga do cartão; a prestação de contas é a da viagem.', ''));
  var meses = grupo(function (a) { return Via_dia_(a.ENVIADO_EM).slice(0, 7); });
  corpo += RelA4_secao_('Por mês e por categoria', tab(meses.sort(function (a, b) { return a.nome.localeCompare(b.nome); }), 'Mês', 'Aditivos por mês') + tab(grupo(function (a) { return Adt_nomeCat_(a.CATEGORIA); }), 'Categoria', 'Aditivos por categoria'));
  corpo += RelA4_secao_('Por técnico e por cliente', tab(grupo(function (a) { return Via_s_(a.SOLICITANTE_NOME); }), 'Quem pediu', 'Aditivos por técnico') + tab(grupo(function (a) { return Via_s_(a.CLIENTE_NOME) || 'Sem cliente (viagem interna)'; }), 'Cliente', 'Aditivos por cliente'));
  corpo += RelA4_secao_('Lista dos aditivos', RelA4_tabela_([{ t: 'Nº e situação' }, { t: 'Pedido por / decidido por' }, { t: 'Categoria e para que é' }, { t: 'Tempo até decidir', num: true }, { t: 'Pedido', num: true }, { t: 'Aprovado', num: true }],
    lista.sort(function (a, b) { return Via_s_(a.ENVIADO_EM).localeCompare(Via_s_(b.ENVIADO_EM)); }).map(function (a) {
      var t = Via_s_(a.DECIDIDO_EM) ? Math.round(Math.max(0, Adt_min_(a.DECIDIDO_EM) - Adt_min_(a.ENVIADO_EM))) + ' min' : '—';
      return [Via_s_(a.NUMERO) + ' · ' + (ADT_SITUACOES[Via_up_(a.SITUACAO)] || a.SITUACAO) + (Via_up_(a.URGENCIA) === 'PARADO' ? ' (parado)' : ''), Via_s_(a.SOLICITANTE_NOME) + ' / ' + (Via_s_(a.DECIDIDO_POR_NOME) || '—'),
        Adt_nomeCat_(a.CATEGORIA) + ': ' + Via_texto_(a.JUSTIFICATIVA, 160) + (Via_up_(a.REPASSAR_CLIENTE) === 'SIM' ? ' · repassar ao cliente' + (Via_s_(a.REPASSE_TRATADO_EM) ? ' (tratado)' : ' (pendente)') : ''), t, m(a.VALOR_PEDIDO), Adt_aprovadoValor_(a) ? m(Adt_aprovadoValor_(a)) : '—'];
    }), { legenda: 'Aditivos do período, pela data do pedido', vazio: 'Nenhum aditivo no período.', compacta: true }));
  return corpo;
}

// ------------------------------------------------------------
// ENTRADA (chamada por Viagem_api)
// ------------------------------------------------------------
function Adt_api_(eu, acao, d) {
  Adt_garantirAba_();
  var r;
  switch (acao) {
    case 'aditivoContexto': return Adt_contexto_(eu);
    case 'aditivoPedir': r = Adt_pedir_(eu, d); break;
    case 'aditivoCancelar': r = Adt_cancelar_(eu, d); break;
    case 'aditivoComplementar': r = Adt_complementar_(eu, d); break;
    case 'aditivoParecer': r = Adt_parecer_(eu, d); break;
    case 'aditivoDecidir': r = Adt_decidir_(eu, d); break;
    case 'aditivoCarga': r = Adt_registrarCarga_(eu, d); break;
    case 'aditivoConferirExcecao': r = Adt_conferirExcecao_(eu, d); break;
    case 'aditivoRepasse': r = Adt_repasse_(eu, d); break;
    default: throw new Error('Não foi possível concluir: ação desconhecida no aditivo de recarga. Atualize a página (F5) e tente de novo.');
  }
  r.contexto = Adt_contexto_(eu);
  return r;
}
