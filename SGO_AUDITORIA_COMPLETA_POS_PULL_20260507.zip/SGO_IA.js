/**
 * SGO_IA.js — METROLABS SGO+
 * Camada de IA para lapidação de textos técnicos do módulo OS.
 *
 * PROVEDOR PADRÃO: Gemini (Google AI Studio — free tier)
 * FALLBACK FUTURO: Anthropic (configurável via IA_PROVIDER)
 *
 * REGRAS DE SEGURANÇA:
 * - Chaves exclusivamente via PropertiesService (nunca no frontend)
 * - A IA nunca salva automaticamente — apenas sugere texto
 * - O usuário precisa revisar e confirmar antes de qualquer gravação
 * - A IA não pode inventar fatos técnicos não informados
 *
 * PROPRIEDADES DO SCRIPT:
 *   GEMINI_API_KEY       — chave do Google AI Studio (obrigatória para GEMINI)
 *   IA_PROVIDER          — "GEMINI" (padrão) ou "ANTHROPIC"
 *   IA_MODEL             — modelo primário (padrão: gemini-2.5-flash)
 *   IA_MODEL_FALLBACKS   — fallbacks separados por vírgula
 *                          ex: gemini-2.5-flash-lite,gemini-2.0-flash-lite,gemini-1.5-flash
 *   ANTHROPIC_API_KEY    — necessária apenas se IA_PROVIDER=ANTHROPIC
 */

var SGO_IA = (function() {

  var MAX_CHARS          = 8000;
  var MAX_TENTATIVAS     = 3;
  var DELAYS_MS          = [800, 1600];   // espera antes da 2ª e 3ª tentativa
  var MODELO_GEMINI_PAD  = "gemini-2.5-flash";
  var MODELO_ANT_PAD     = "claude-haiku-4-5-20251001";
  var FALLBACKS_PADRAO   = ["gemini-2.5-flash-lite", "gemini-2.0-flash-lite", "gemini-1.5-flash"];
  var ENDPOINT_GEMINI    = "https://generativelanguage.googleapis.com/v1beta/models/";
  var ENDPOINT_ANT       = "https://api.anthropic.com/v1/messages";
  var ANT_VER            = "2023-06-01";

  var REGRAS_BASE =
    "Você é um assistente de redação técnica para ordens de serviço de engenharia clínica.\n" +
    "REGRAS ABSOLUTAS — nunca viole:\n" +
    "1. Nunca invente dados ausentes: medição, resultado de teste, peça trocada, aprovação, " +
       "calibração, qualificação, evidência fotográfica, assinatura, resultado não informado.\n" +
    "2. Preserve todos os fatos, valores numéricos e termos técnicos do texto original.\n" +
    "3. Não adicione informações que não estão no texto fornecido.\n" +
    "4. Responda SOMENTE com o texto solicitado, sem prefácio, sem comentário, sem aspas.\n" +
    "5. Use português brasileiro formal e técnico.\n" +
    "6. Não use markdown, negrito, itálico ou listas — apenas texto corrido.";

  /* ------------------------------------------------------------------ */
  /*  Configuração via PropertiesService                                  */
  /* ------------------------------------------------------------------ */

  function obterConfig_() {
    var props    = PropertiesService.getScriptProperties();
    var provider = (props.getProperty("IA_PROVIDER") || "GEMINI").toUpperCase().trim();
    var model    = (props.getProperty("IA_MODEL") || "").trim();
    var fbProp   = (props.getProperty("IA_MODEL_FALLBACKS") || "").trim();
    return {
      provider:     provider,
      model:        model || (provider === "ANTHROPIC" ? MODELO_ANT_PAD : MODELO_GEMINI_PAD),
      fallbacksRaw: fbProp,
      geminiKey:    props.getProperty("GEMINI_API_KEY")    || "",
      anthropicKey: props.getProperty("ANTHROPIC_API_KEY") || ""
    };
  }

  function obterListaModelos_(cfg) {
    var lista = [cfg.model];
    var fb = cfg.fallbacksRaw
      ? cfg.fallbacksRaw.split(",").map(function(m) { return m.trim(); }).filter(Boolean)
      : FALLBACKS_PADRAO.slice();
    fb.forEach(function(m) {
      if (lista.indexOf(m) === -1) lista.push(m);
    });
    return lista;
  }

  /* ------------------------------------------------------------------ */
  /*  Tratamento de erros HTTP                                            */
  /* ------------------------------------------------------------------ */

  function interpretarErro_(codigo, corpo, provedor) {
    var msgApi = (corpo && corpo.error && (corpo.error.message || corpo.error.status)) || ("HTTP " + codigo);
    if (codigo === 401 || codigo === 403) {
      return "Chave " + provedor + " inválida ou sem autorização (HTTP " + codigo + "). " +
             "Verifique a propriedade do script.";
    }
    if (codigo === 429) {
      return "Limite de uso gratuito do Gemini atingido (HTTP 429). " +
             "Aguarde alguns minutos e tente novamente.";
    }
    if (codigo === 404) {
      return "Modelo não encontrado (HTTP 404): " + msgApi;
    }
    if (codigo >= 500) {
      return "Serviço temporariamente indisponível (HTTP " + codigo + "): " + msgApi;
    }
    return "Erro na API Gemini (HTTP " + codigo + "): " + msgApi;
  }

  function eRetentavel_(codigo) {
    return codigo === 500 || codigo === 503;
  }

  /* ------------------------------------------------------------------ */
  /*  Chamada Gemini com retry e fallback de modelo                       */
  /* ------------------------------------------------------------------ */

  function chamarGemini_(prompt, cfg, maxTokens) {
    if (!cfg.geminiKey) {
      throw new Error(
        "Chave GEMINI_API_KEY não configurada. " +
        "Acesse o editor GAS > Configurações do projeto > Propriedades do script."
      );
    }

    var modelos   = obterListaModelos_(cfg);
    var ultimoErr = "Gemini está temporariamente indisponível. Tente novamente em alguns instantes.";

    for (var mi = 0; mi < modelos.length; mi++) {
      var modelo = modelos[mi];

      for (var tent = 0; tent < MAX_TENTATIVAS; tent++) {
        if (tent > 0) Utilities.sleep(DELAYS_MS[tent - 1] || 1600);

        Logger.log("[SGO_IA] modelo=" + modelo + " tentativa=" + (tent + 1) + "/" + MAX_TENTATIVAS);

        var url  = ENDPOINT_GEMINI + modelo + ":generateContent?key=" + cfg.geminiKey;
        var resp = UrlFetchApp.fetch(url, {
          method:             "post",
          muteHttpExceptions: true,
          contentType:        "application/json",
          payload: JSON.stringify({
            contents:         [{ parts: [{ text: prompt }] }],
            generationConfig: { maxOutputTokens: maxTokens || 800 }
          })
        });

        var codigo = resp.getResponseCode();
        var corpo  = {};
        try { corpo = JSON.parse(resp.getContentText()); } catch (_) {}

        var msgResumida = (corpo && corpo.error && corpo.error.message) || ("HTTP " + codigo);
        Logger.log("[SGO_IA] http=" + codigo + " modelo=" + modelo + " msg=" + msgResumida);

        if (codigo === 200) {
          var texto =
            corpo.candidates &&
            corpo.candidates[0] &&
            corpo.candidates[0].content &&
            corpo.candidates[0].content.parts &&
            corpo.candidates[0].content.parts[0] &&
            corpo.candidates[0].content.parts[0].text;
          if (!texto) throw new Error("Gemini retornou resposta vazia. Tente novamente.");
          Logger.log("[SGO_IA] sucesso modelo=" + modelo + " tentativa=" + (tent + 1));
          return String(texto).trim();
        }

        if (codigo === 401 || codigo === 403) {
          throw new Error(interpretarErro_(codigo, corpo, "GEMINI_API_KEY"));
        }

        if (codigo === 429) {
          throw new Error(interpretarErro_(codigo, corpo, "GEMINI_API_KEY"));
        }

        if (codigo === 404) {
          Logger.log("[SGO_IA] modelo " + modelo + " nao encontrado (404). Pulando para proximo fallback.");
          ultimoErr = "Modelo " + modelo + " não encontrado. Tentando próximo.";
          break;
        }

        ultimoErr = interpretarErro_(codigo, corpo, "GEMINI");
        if (!eRetentavel_(codigo)) break;
      }
    }

    throw new Error(ultimoErr);
  }

  /* ------------------------------------------------------------------ */
  /*  Chamada Anthropic (fallback configurável)                           */
  /* ------------------------------------------------------------------ */

  function chamarAnthropic_(prompt, cfg, maxTokens) {
    if (!cfg.anthropicKey) {
      throw new Error(
        "Chave ANTHROPIC_API_KEY não configurada. " +
        "Acesse o editor GAS > Configurações do projeto > Propriedades do script."
      );
    }
    var resp = UrlFetchApp.fetch(ENDPOINT_ANT, {
      method:             "post",
      muteHttpExceptions: true,
      headers: {
        "x-api-key":         cfg.anthropicKey,
        "anthropic-version": ANT_VER,
        "content-type":      "application/json"
      },
      payload: JSON.stringify({
        model:      cfg.model,
        max_tokens: maxTokens || 800,
        messages:   [{ role: "user", content: prompt }]
      })
    });

    var codigo = resp.getResponseCode();
    var corpo  = {};
    try { corpo = JSON.parse(resp.getContentText()); } catch (_) {}

    if (codigo !== 200) {
      throw new Error(interpretarErro_(codigo, corpo, "ANTHROPIC_API_KEY"));
    }

    var texto = corpo.content && corpo.content[0] && corpo.content[0].text;
    if (!texto) throw new Error("Anthropic retornou resposta vazia. Tente novamente.");
    return String(texto).trim();
  }

  /* ------------------------------------------------------------------ */
  /*  Roteador de provedor                                                */
  /* ------------------------------------------------------------------ */

  function chamarApi_(prompt, maxTokens) {
    var cfg = obterConfig_();
    if (cfg.provider === "ANTHROPIC") return chamarAnthropic_(prompt, cfg, maxTokens);
    return chamarGemini_(prompt, cfg, maxTokens);
  }

  /* ------------------------------------------------------------------ */
  /*  Helpers internos                                                    */
  /* ------------------------------------------------------------------ */

  function validarTexto_(texto) {
    var t = String(texto || "").trim();
    if (!t)            throw new Error("Campo vazio. Preencha o texto antes de usar a IA.");
    if (t.length < 8)  throw new Error("Texto muito curto para processar.");
    if (t.length > MAX_CHARS) {
      throw new Error("Texto muito longo (" + t.length + " chars). Limite: " + MAX_CHARS + ".");
    }
    return t;
  }

  function contextoStr_(ctx) {
    var partes = [];
    if (ctx.tipo)        partes.push("Tipo OS: "             + ctx.tipo);
    if (ctx.equipamento) partes.push("Equipamento: "         + ctx.equipamento);
    if (ctx.cliente)     partes.push("Cliente: "             + ctx.cliente);
    if (ctx.missao)      partes.push("Missão técnica: "      + ctx.missao);
    if (ctx.relato)      partes.push("Relato técnico: "      + ctx.relato);
    if (ctx.diagnostico) partes.push("Diagnóstico: "         + ctx.diagnostico);
    if (ctx.condicao)    partes.push("Condição encontrada: " + ctx.condicao);
    if (ctx.causa)       partes.push("Causa provável: "      + ctx.causa);
    if (ctx.resultado)   partes.push("Resultado: "           + ctx.resultado);
    if (ctx.pendencias)  partes.push("Pendências: "          + ctx.pendencias);
    return partes.join("\n");
  }

  /* ------------------------------------------------------------------ */
  /*  Funções exportadas                                                  */
  /* ------------------------------------------------------------------ */

  function lapidarTexto(sessionId, payload) {
    exigirSessao(sessionId);
    var texto = validarTexto_(payload && payload.texto);
    var campo = SGO_UTILS.safe((payload && payload.campo) || "campo técnico");
    var prompt =
      REGRAS_BASE + "\n\n" +
      "Tarefa: Lapidar o texto do campo '" + campo + "' de uma OS. " +
      "Corrija gramática, pontuação e clareza. Não altere os fatos técnicos.\n\n" +
      "Texto original:\n" + texto;
    return { success: true, texto: chamarApi_(prompt, 800) };
  }

  function gerarTextoTecnicoOS(sessionId, payload) {
    exigirSessao(sessionId);
    var ctx = (payload && payload.contexto) || {};
    if (!ctx.relato && !ctx.missao) {
      throw new Error("Informe ao menos o relato ou a missão técnica para gerar o texto.");
    }
    var prompt =
      REGRAS_BASE + "\n\n" +
      "Tarefa: Com base nas informações abaixo de uma OS, gere um relato técnico completo, " +
      "claro e profissional. Use apenas os dados fornecidos. " +
      "Não invente nenhum detalhe técnico não informado.\n\n" +
      contextoStr_(ctx);
    return { success: true, texto: chamarApi_(prompt, 1000) };
  }

  function corrigirPortuguesBR(sessionId, payload) {
    exigirSessao(sessionId);
    var texto = validarTexto_(payload && payload.texto);
    var prompt =
      REGRAS_BASE + "\n\n" +
      "Tarefa: Corrija apenas a ortografia e gramática do texto abaixo em português brasileiro. " +
      "Não altere o conteúdo, os termos técnicos, os dados ou a estrutura das frases.\n\n" +
      "Texto:\n" + texto;
    return { success: true, texto: chamarApi_(prompt, 800) };
  }

  function criarResumoExecutivoOS(sessionId, payload) {
    exigirSessao(sessionId);
    var ctx = (payload && payload.contexto) || {};
    if (!ctx.relato && !ctx.tipo) {
      throw new Error("Informe ao menos o relato ou o tipo da OS para gerar o resumo.");
    }
    var prompt =
      REGRAS_BASE + "\n\n" +
      "Tarefa: Gere um resumo executivo de 2 a 3 frases para esta OS. " +
      "O resumo deve ser objetivo, técnico e adequado para leitura gerencial. " +
      "Use apenas os dados fornecidos.\n\n" +
      contextoStr_(ctx);
    return { success: true, texto: chamarApi_(prompt, 400) };
  }

  function criarConclusaoTecnicaOS(sessionId, payload) {
    exigirSessao(sessionId);
    var ctx = (payload && payload.contexto) || {};
    if (!ctx.relato) {
      throw new Error("Informe o relato técnico para gerar a conclusão.");
    }
    var prompt =
      REGRAS_BASE + "\n\n" +
      "Tarefa: Gere uma conclusão técnica para esta OS. " +
      "A conclusão deve sintetizar o que foi feito e o estado final do equipamento. " +
      "Use apenas os dados fornecidos.\n\n" +
      contextoStr_(ctx);
    return { success: true, texto: chamarApi_(prompt, 500) };
  }

  function criarRecomendacaoTecnicaOS(sessionId, payload) {
    exigirSessao(sessionId);
    var ctx = (payload && payload.contexto) || {};
    if (!ctx.relato) {
      throw new Error("Informe o relato técnico para gerar a recomendação.");
    }
    var prompt =
      REGRAS_BASE + "\n\n" +
      "Tarefa: Gere uma recomendação técnica para esta OS. " +
      "Liste apenas recomendações pertinentes com base nos dados informados. " +
      "Não invente necessidades não relatadas.\n\n" +
      contextoStr_(ctx);
    return { success: true, texto: chamarApi_(prompt, 500) };
  }

  return {
    lapidarTexto:               lapidarTexto,
    gerarTextoTecnicoOS:        gerarTextoTecnicoOS,
    corrigirPortuguesBR:        corrigirPortuguesBR,
    criarResumoExecutivoOS:     criarResumoExecutivoOS,
    criarConclusaoTecnicaOS:    criarConclusaoTecnicaOS,
    criarRecomendacaoTecnicaOS: criarRecomendacaoTecnicaOS
  };

})();

/* -------------------------------------------------------------------- */
/*  Wrappers públicos — chamáveis via google.script.run                  */
/* -------------------------------------------------------------------- */

function iaLapidarTexto(sessionId, payload) {
  try { return JSON.parse(JSON.stringify(SGO_IA.lapidarTexto(sessionId, payload))); }
  catch (e) { return { success: false, message: e.message }; }
}

function iaGerarTextoTecnicoOS(sessionId, payload) {
  try { return JSON.parse(JSON.stringify(SGO_IA.gerarTextoTecnicoOS(sessionId, payload))); }
  catch (e) { return { success: false, message: e.message }; }
}

function iaCorrigirPortuguesBR(sessionId, payload) {
  try { return JSON.parse(JSON.stringify(SGO_IA.corrigirPortuguesBR(sessionId, payload))); }
  catch (e) { return { success: false, message: e.message }; }
}

function iaCriarResumoExecutivoOS(sessionId, payload) {
  try { return JSON.parse(JSON.stringify(SGO_IA.criarResumoExecutivoOS(sessionId, payload))); }
  catch (e) { return { success: false, message: e.message }; }
}

function iaCriarConclusaoTecnicaOS(sessionId, payload) {
  try { return JSON.parse(JSON.stringify(SGO_IA.criarConclusaoTecnicaOS(sessionId, payload))); }
  catch (e) { return { success: false, message: e.message }; }
}

function iaCriarRecomendacaoTecnicaOS(sessionId, payload) {
  try { return JSON.parse(JSON.stringify(SGO_IA.criarRecomendacaoTecnicaOS(sessionId, payload))); }
  catch (e) { return { success: false, message: e.message }; }
}
